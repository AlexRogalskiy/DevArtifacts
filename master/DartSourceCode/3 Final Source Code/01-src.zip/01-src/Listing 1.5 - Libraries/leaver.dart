part of myLibrary;


class Leaver {

}
