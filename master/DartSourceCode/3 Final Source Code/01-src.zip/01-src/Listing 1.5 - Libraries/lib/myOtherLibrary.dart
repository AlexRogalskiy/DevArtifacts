library MyOtherLibrary;


sayHello(g) {

}