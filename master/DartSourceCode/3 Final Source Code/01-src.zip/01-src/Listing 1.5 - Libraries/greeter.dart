part of myLibrary;


class Greeter {

}
