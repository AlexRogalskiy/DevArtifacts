/// This is the entry point function
///  and outputs Hello World to the console
main() {
  print("Hello World");
}