
import 'dart:html';

void main() {
  query('#status').innerHTML = "Hello World";
}
