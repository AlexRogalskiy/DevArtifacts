How could this be improved?

1. Error handling
2. Take a filename pattern to match from the client side (instead of hard coded .dart files)
3. Client side: Return the file loaded into a <textarea>, and allow the user to edit it and click save
4. Server side: Accept the "saved" file, and update the file on the local filesystem