part of cake_baking;

class Oven {
  static void setTemperature(temp) {
    
  }
  
  
}