package edu.packt.neuralnet.learn;

import edu.packt.neuralnet.NeuralNet;

public class Adaline extends Training {

	public NeuralNet train(NeuralNet n) {

		return super.train(n);

	}

}


