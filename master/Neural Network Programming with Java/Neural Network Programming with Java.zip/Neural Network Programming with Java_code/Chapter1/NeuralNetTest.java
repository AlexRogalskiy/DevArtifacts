package edu.packt.neuralnet;

public class NeuralNetTest {
	public static void main(String[] args) {
		NeuralNet n = new NeuralNet();
		n.initNet();
		n.printNet();
	}
}
