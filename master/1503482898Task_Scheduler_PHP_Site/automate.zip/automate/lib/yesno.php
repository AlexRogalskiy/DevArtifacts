<?php
$TASKMODULENAME = 'yesno.php';
Logbook ("DEBUG: $TASKMODULENAME START");
sleep (5);
Logbook ("DEBUG: $TASKMODULENAME FINISH");
$res = rand (0, 1)? FALSE: TRUE;
?>