<?hh

var_dump(get_declared_classes());