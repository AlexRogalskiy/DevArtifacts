<?php
$sleep = $_SERVER['QUERY_STRING'];
sleep($sleep);
echo $sleep, PHP_EOL;