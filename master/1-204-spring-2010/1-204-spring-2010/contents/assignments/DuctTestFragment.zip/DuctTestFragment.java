package src.hw6S09;

public class DuctTestFragment {
	public static final double MIN_D= 0.3;
	public static final double MAX_D= 1.5;
	public static final double MIN_V= 1.0;
	public static final double MAX_V= 10.0;
	
	public static void main(String[] args) {
		// Create tree that models the ducts in the building
		DuctTree tree= new DuctTree(50.0, 0.14, 0.15);		// Cost of duct (cd), crf (crf), cost of electricity (ce)
		
		// Create nodes that represent each duct
		// Constructor has: duct number, left child, right child, flow, length, min/max duct diameter, min/max velocity
		// Constructor assumes DuctNode is inner class of DuctTree. If DuctNode is its own class, remove DuctTree. and tree. from lines below
		DuctTree.DuctNode n1 = tree.new DuctNode(1, null, null,   0.70, 20.0, MIN_D, MAX_D, MIN_V, MAX_V);	// Nodes 1-15 are end nodes; flow is input
		DuctTree.DuctNode n2 = tree.new DuctNode(2, null, null,   0.47, 12.0, MIN_D, MAX_D, MIN_V, MAX_V);
		DuctTree.DuctNode n3 = tree.new DuctNode(3, null, null,   0.33, 36.5, MIN_D, MAX_D, MIN_V, MAX_V);
		DuctTree.DuctNode n4 = tree.new DuctNode(4, null, null,  10.56,  5.0, MIN_D, MAX_D, MIN_V, MAX_V);
		DuctTree.DuctNode n5 = tree.new DuctNode(5, null, null,   0.26, 10.2, MIN_D, MAX_D, MIN_V, MAX_V);
		DuctTree.DuctNode n6 = tree.new DuctNode(6, null, null,   1.05, 69.8, MIN_D, MAX_D, MIN_V, MAX_V);
		DuctTree.DuctNode n7 = tree.new DuctNode(7, null, null,   1.06, 23.0, MIN_D, MAX_D, MIN_V, MAX_V);
		DuctTree.DuctNode n8 = tree.new DuctNode(8, null, null,   0.61, 37.8, MIN_D, MAX_D, MIN_V, MAX_V);
		DuctTree.DuctNode n9 = tree.new DuctNode(9, null, null,   0.72, 18.0, MIN_D, MAX_D, MIN_V, MAX_V);
		DuctTree.DuctNode n10 = tree.new DuctNode(10, null, null, 1.72, 21.4, MIN_D, MAX_D, MIN_V, MAX_V);
		DuctTree.DuctNode n11 = tree.new DuctNode(11, null, null, 1.72, 21.4, MIN_D, MAX_D, MIN_V, MAX_V);
		DuctTree.DuctNode n12 = tree.new DuctNode(12, null, null, 0.50, 22.0, MIN_D, MAX_D, MIN_V, MAX_V);
		DuctTree.DuctNode n13 = tree.new DuctNode(13, null, null, 0.53, 22.0, MIN_D, MAX_D, MIN_V, MAX_V);
		DuctTree.DuctNode n14 = tree.new DuctNode(14, null, null, 0.37, 30.5, MIN_D, MAX_D, MIN_V, MAX_V);

		DuctTree.DuctNode n15 = tree.new DuctNode(15, n1, n2,   0.0,  3.0, MIN_D, MAX_D, MIN_V, MAX_V);		// Nodes 16-27 have feeder ducts; flow is computed
		DuctTree.DuctNode n16 = tree.new DuctNode(16, n4, n5,   0.0, 62.5, MIN_D, MAX_D, MIN_V, MAX_V);
		DuctTree.DuctNode n17 = tree.new DuctNode(17, n6, n7,   0.0, 27.4, MIN_D, MAX_D, MIN_V, MAX_V);
		DuctTree.DuctNode n18 = tree.new DuctNode(18, n8, n9,   0.0,  7.0, MIN_D, MAX_D, MIN_V, MAX_V);
		DuctTree.DuctNode n19 = tree.new DuctNode(19, n15, n3,  0.0, 15.0, MIN_D, MAX_D, MIN_V, MAX_V);
		DuctTree.DuctNode n20 = tree.new DuctNode(20, n10, n18, 0.0, 14.4, MIN_D, MAX_D, MIN_V, MAX_V);
		DuctTree.DuctNode n21 = tree.new DuctNode(21, n19, n16, 0.0,  6.2, MIN_D, MAX_D, MIN_V, MAX_V);
		DuctTree.DuctNode n22 = tree.new DuctNode(22, n11, n20, 0.0,  6.4, MIN_D, MAX_D, MIN_V, MAX_V);
		DuctTree.DuctNode n23 = tree.new DuctNode(23, n12, n22, 0.0, 16.0, MIN_D, MAX_D, MIN_V, MAX_V);
		DuctTree.DuctNode n24 = tree.new DuctNode(24, n13, n23, 0.0, 63.0, MIN_D, MAX_D, MIN_V, MAX_V);
		DuctTree.DuctNode n25 = tree.new DuctNode(25, n17, n24, 0.0, 36.7, MIN_D, MAX_D, MIN_V, MAX_V);
		DuctTree.DuctNode n26 = tree.new DuctNode(26, n14, n25, 0.0, 38.0, MIN_D, MAX_D, MIN_V, MAX_V);
		DuctTree.DuctNode n27 = tree.new DuctNode(27, n26, n21, 0.0,  1.0, MIN_D, MAX_D, MIN_V, 3*MAX_V);
		tree.root= n27;
		// Call your dynamic programming methods to find solution
	}
}