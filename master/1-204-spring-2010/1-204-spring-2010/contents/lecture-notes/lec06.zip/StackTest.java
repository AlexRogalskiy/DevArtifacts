package src.dataStructures;
public class StackTest {
	public static void main(String args[]) {
		int[] array = { 12, 13, 14, 15, 16, 17 };
		Stack stack = new Stack();
		for (int i : array) {
			stack.push(i);
		}
		while (!stack.isEmpty()) {
			int z= (Integer) stack.pop();
			System.out.println(z);
		}
	}	// Should have try/catch block to catch exceptions
}