package src.dataStructures;

public class Phone implements Comparable<Object> {
	private String name;		// Name of person
	private int phone;			// Phone number
	
	public Phone(String n, int p) {
		name= n;
		phone= p;
	}
	
	public int compareTo(Object other) {
		Phone o= (Phone) other;
		return name.compareTo(o.name);
	}
	
	public String toString() {
		return("Name: "+ name +" phone: "+ phone);
	}
}
