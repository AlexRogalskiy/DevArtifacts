package src.dataStructures;
import java.util.*;

public class Stack {
	public static final int DEFAULT_CAPACITY = 8;
	private Object[] stack;
	private int top = -1;
	private int capacity;

	public Stack(int cap) {
		capacity = cap;
		stack = new Object[capacity];
	}
	public Stack() {
		this(DEFAULT_CAPACITY);
	}

	public boolean isEmpty() {
		return (top == -1);
	}

	public void clear() {
		top = -1;
	}

	public void push(Object o) {
		if (top == capacity - 1)
			grow();
		stack[++top] = o;
	}

	private void grow() {
		capacity *= 2;
		Object[] oldStack = stack;
		stack = new Object[capacity];
		System.arraycopy(oldStack, 0, stack, 0, top);
	}
	public Object pop() throws NoSuchElementException {
		if (isEmpty())
			throw new NoSuchElementException();
		else {
			return stack[top--];
		}
	}
}