package src.dataStructures;
public class TreeGeneric<K extends Comparable<K>, V> {
    private Node root;
    
    public TreeGeneric() {
        root= null;
    }
    
	public void inorder() {
		if (root != null)
			root.traverseInorder();
	}
    
	public void postorder() {
		if (root != null)
			root.traversePostorder();
	}
    
    public void insert(K k, V v) {
        Node t= new Node(k, v);
        if (root==null)
            root= t;
        else
            root.insertNode(t);
    }
    
    public boolean find(Node o) {  // Was Comparable
        if (root== null)
            return false;
        else
            return root.findNode(o);
    }
    
    public void print() {
        if (root != null)
            root.printNodes();
    }
    

    public class Node implements Comparable<Node> {	
    	K key;
    	V value;
        public Node left;
        public Node right;
        
        public Node(K k, V v) {
        	this.key = k;
    		this.value = v;
            left= null;
            right= null;
        }
        
        public int compareTo(Node o) {
        	K me= this.key;
        	K other= o.key;
        	return me.compareTo(other);
//        	return this.key.compareTo(o.key);
    	}
        
        public String toString() {
    		return "Key: " + this.key + " Value: " + this.value;
    	}
        
        public void insertNode(Node n) {
            if (this.compareTo(n) > 0) {
                if (left==null)
                    left= n;
                else
                    left.insertNode(n);
            }
            else {
                if (right == null)
                    right= n;
                else
                    right.insertNode(n);
            }
        }
        
        public boolean findNode(Node o) {
            if (this.compareTo(o) > 0) {
                if (left== null)
                    return false;
                else
                    return left.findNode(o);
            }
            else if (this.compareTo(o) < 0) {
                if (right == null)
                    return false;
                else 
                    return right.findNode(o);
            }
            else {   // Equal
            	System.out.println("  Found " + key);
                return true;
            }
        }
        
        public void traverseInorder()
		{
			if (left != null) left.traverseInorder();
			System.out.println(key);
			if (right != null) right.traverseInorder();
		}
        
        public void traversePostorder() {
        	if (left != null) left.traversePostorder();
			if (right != null) right.traversePostorder();
			System.out.println(key);
        }
                      
        public void printNodes() {
            if (left != null)
                left.printNodes();
            System.out.println(key);
            if (right != null)
                right.printNodes();
        }
    }
}