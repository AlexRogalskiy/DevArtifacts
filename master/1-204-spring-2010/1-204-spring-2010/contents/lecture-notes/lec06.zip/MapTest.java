package src.dataStructures;
public class MapTest {
    public static void main(String[] args) {
        Tree z= new Tree();
        z.insert(new Phone("Betty", 4411));
        z.insert(new Phone("Quantum", 1531));
        z.insert(new Phone("Thomas", 6651));
        z.insert(new Phone("Darlene", 8343));
        z.insert(new Phone("Alice", 6334));
        z.print();
        System.out.println(" Inorder");
        z.inorder();
        System.out.println(" Postorder");
        z.postorder();   
        System.out.println(" Search for phone numbers");
        System.out.println("Find Betty? " + z.find(new Phone("Betty", -1)));
        System.out.println("Find Thomas? " + z.find(new Phone("Thomas", -1)));
        System.out.println("Find Alan? " + z.find(new Phone("Alan", -1)));
    }
}