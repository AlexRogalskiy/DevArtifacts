package src.dataStructures;
public class Tree {
    private Node root;
    
    public Tree() {
        root= null;
    }
    
	public void inorder() {
		if (root != null)
			root.traverseInorder();
	}
    
	public void postorder() {
		if (root != null)
			root.traversePostorder();
	}
	@SuppressWarnings("unchecked")
    public void insert(Comparable o) {
        Node t= new Node(o);
        if (root==null)
            root= t;
        else
            root.insertNode(t);
    }
	@SuppressWarnings("unchecked")
    public boolean find(Comparable o) {
        if (root== null)
            return false;
        else
            return root.findNode(o);
    }
    
    public void print() {
        if (root != null)
            root.printNodes();
    }
    
	@SuppressWarnings("unchecked")
    private static class Node {					// Can be static
        public Comparable data;
        public Node left;
        public Node right;
        
        public Node(Comparable o) {
            data= o;
            left= null;
            right= null;
        }
        
        public void insertNode(Node n) {
            if (data.compareTo(n.data) > 0) {
                if (left==null)
                    left= n;
                else
                    left.insertNode(n);
            }
            else {
                if (right == null)
                    right= n;
                else
                    right.insertNode(n);
            }
        }
        
        public boolean findNode(Comparable o) {
            if (data.compareTo(o) > 0) {
                if (left== null)
                    return false;
                else
                    return left.findNode(o);
            }
            else if (data.compareTo(o) < 0) {
                if (right == null)
                    return false;
                else 
                    return right.findNode(o);
            }
            else {   // Equal
            	System.out.println("  Found " +data);
                return true;
            }
        }
        
        public void traverseInorder() {
			if (left != null) left.traverseInorder();
			System.out.println(data);
			if (right != null) right.traverseInorder();
		}
        
        public void traversePostorder() {
        	if (left != null) left.traversePostorder();
			if (right != null) right.traversePostorder();
			System.out.println(data);
        }
        
        public void printNodes() {
            if (left != null)
                left.printNodes();
            System.out.println(data);
            if (right != null)
                right.printNodes();
        }
    }
}