package src.dataStructures;
public class TreeTest {
    public static void main(String[] args) {
        Tree z= new Tree();
        System.out.println("Insert nodes");
        z.insert("b");
        z.insert("q");
        z.insert("t");
        z.insert("d");
        z.insert("a");
        z.print();
        System.out.println(" Inorder");
        z.inorder();
        System.out.println(" Postorder");
        z.postorder();   
        System.out.println(" Search results");
        System.out.println("Find q? " + z.find("q"));
        System.out.println("Find b? " + z.find("b"));
        System.out.println("Find t? " + z.find("t"));
        System.out.println("Find d? " + z.find("d"));
        System.out.println("Find a? " + z.find("a"));
        System.out.println("Find x? " + z.find("x"));
    }
}