package src.dataStructures;
public class QueueTest {
	public static void main(String args[]) {
		int[] array = { 12, 13, 14, 15, 16, 17 };
		Queue queue = new Queue();
		for (int i : array) {
			queue.add(i);
		}
		while (!queue.isEmpty()) {
			int z= (Integer) queue.remove();
			System.out.println(z);
		}
	}	// Should have try/catch block for exceptions
}