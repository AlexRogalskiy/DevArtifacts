package src.dataStructures;
import java.util.*;

public class Queue {
    static public final int DEFAULT_CAPACITY= 8;
    private Object[] queue;
    private int front;
    private int rear;
    private int capacity;
    private int size = 0;

    public Queue(int cap) {
        capacity = cap;
        front = 0;
        rear = capacity - 1;
        queue= new Object[capacity];
    }
    
    public Queue() {
        this( DEFAULT_CAPACITY );
    }
    
    public void add(Object o) {
        if ( size == capacity )
            grow();
        rear = ( rear + 1 ) % capacity;
        queue[ rear ] = o;
        size++;
    }
    
    public Object remove() throws NoSuchElementException {
        if ( isEmpty() )
            throw new NoSuchElementException();
        else {
            Object ret = queue[ front ];
            front = (front + 1) % capacity;
            size--;
            return ret;
        }
    }
    
    public boolean isEmpty() {
        return ( size == 0 );
    }
    
    public void clear() {
        size = 0;
        front = 0;
        rear = capacity - 1;
    }
    
    private void grow() {
        Object[] old= queue;
        int oldCapacity= capacity;
        capacity *= 2;
        queue= new Object[capacity];
        if ( size == 0 )
            return;
        if ( front <= rear ) {
            System.arraycopy(old, front, queue, 0, size );
        }
        else if ( rear < front ) {
            int nFront= oldCapacity-front;
            System.arraycopy(old, front, queue, 0, nFront);
            System.arraycopy(old, 0, queue, nFront, size-nFront );
        }
        front= 0;
        rear= size-1;
    }
}