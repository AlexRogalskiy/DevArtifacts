package src.dataStructures;
public class TreeTestGeneric {
    public static void main(String[] args) {
        TreeGeneric<String, Integer> z= new TreeGeneric<String,Integer>();
        System.out.println(" Insert nodes");
        z.insert("Betty", 4411);
        z.insert("Quantum", 1531);
        z.insert("Thomas", 6651);
        z.insert("Darlene", 8343);
        z.insert("Alice", 6334);
        z.print();
        System.out.println(" Inorder");
        z.inorder();
        System.out.println(" Postorder");
        z.postorder();   
        System.out.println(" Search for phone numbers");
        System.out.println("Find Betty? " + z.find(z.new Node("Betty", -1)));
        System.out.println("Find Thomas? " + z.find(z.new Node("Thomas", -1)));
        System.out.println("Find Alan? " + z.find(z.new Node("Alan", -1)));
    }
}