package src.greedy;

public class MSTArc implements Comparable<Object> {
	int from;	// Package access
	int to;		// Package access
	int dist;	// Package access
	
	public MSTArc(int f, int t, int d) {
		from= f;
		to= t;
		dist= d;
	}
	
	public String toString() {
		return (" from: "+ from+ " to: "+ to + " dist: "+ dist);
	}
	
	public int compareTo(Object o) {
		MSTArc other = (MSTArc) o;
		if (dist > other.dist)		// Ascending sort
			return -1;
		else if (dist < other.dist)
			return 1;
		else
			return 0;
	}
}