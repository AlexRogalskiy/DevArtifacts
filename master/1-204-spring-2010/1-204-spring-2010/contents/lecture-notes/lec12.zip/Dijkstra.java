package src.greedy;
import src.dataStructures.Heap;

public class Dijkstra {
    private int nodes;
    private int arcs;
    private int[] head;
    private int[] to;
    private int[] dist;
	private int[] D;                    // Distance from root
	private int[] P;                    // Predecessor node back to root
	private Heap g;
    
    Dijkstra(int n, int a, int[] h, int[] t, int[] d) {
        nodes= n;
        arcs= a;
        head= h;
        to= t;
        dist= d;
        g= new Heap(arcs);
    }
    
    public void print() {
    	System.out.println("i \tP \tD");
    	for (int i=0; i < nodes; i++) {
    		if (P[i] == Short.MIN_VALUE)
    			System.out.println(i + "\t- \t" + D[i]);
    		else
				System.out.println(i + "\t" + P[i] + "\t" + D[i]);
    	}
    }
    
    public void shortDijkstra(int root) {
        final int MAX_COST= Integer.MAX_VALUE/2;    // 'Infinite' initial value
        final int EMPTY= Short.MIN_VALUE;           // Flag for no value: -32767
        
		D= new int[nodes];                    		// Distance from root
		P= new int[nodes];                    		// Predecessor node from root
        
        for (int i=0; i < nodes; i++) {             // Initialize all nodes
            D[i]= MAX_COST;                         // Initial label-> infinity
            P[i]= EMPTY;                            // No predecessor on path
        }
        
		MSTArc inArc= null;
        D[root]= 0;                                 // Root is 0 distance from root
		for (int arc= head[root]; arc< head[root+1]; arc++)
			g.insert(new MSTArc(root, to[arc], dist[arc]));
		
		for (int i = 0; i < nodes-1; i++) {	
			do {
				if (g.isEmpty()) return;
				inArc= (MSTArc) g.delete();
			} while (P[inArc.to]!= EMPTY);		// "To" node cannot be in tree already
			int inNode= inArc.to;				// Node added to shortest path tree
			P[inNode]= inArc.from;				// Its predecessor is "from" node
			D[inNode]= inArc.dist; 				// Distance from root (see heap insert below)
			// Add arcs to heap from newly added node, with the labels of their "to" node
			for (int arc= head[inNode]; arc< head[inNode+1]; arc++)
				g.insert(new MSTArc(inNode, to[arc], D[inNode] + dist[arc]));
		}
    }
 
    public static void main(String[] args) {
        // Test graph for graph lecture notes
        int nodes= 4;
        int arcs= 4;
        int root= 0;
        int[] head= new int[nodes+1];
        int[] to= new int[arcs];
        int[] dist= new int[arcs];
        head[0]= 0; head[1]= 2; head[2]= 3; head[3]= 3; head[4]= 4;
        to[0]= 1;   to[1]= 3;   to[2]= 2;   to[3]= 1;
        dist[0]= 3; dist[1]= 1; dist[2]= 2; dist[3]= 1;
        Dijkstra g= new Dijkstra(nodes, arcs, head, to, dist);
        g.shortDijkstra(root);
        g.print();
    }
}