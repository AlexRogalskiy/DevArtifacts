package src.greedy;
import java.io.*;
import java.util.*;

import src.dataStructures.Heap;

public class Graph {
	private int to[];
	private int dist[];
	private int H[];
	private int nodes;
	private int arcs;
	private int[] D;	// Distance from root to node. Used in shortest path methods
	private int[] P;	// Predecessor node on path from root. Used in shortest path methods
	
	public int getNodes() {
		return nodes;
	}
	
	public int[] getD() {
		return D;
	}

	public int[] getP() {
		return P;
	}

	public Graph(String filename) {
		Arc[] graph= null;		// graph is discarded at end of constructor
		try {
			FileReader fin= new FileReader(filename);
			BufferedReader in= new BufferedReader(fin);
			graph= readData(in);	// also sets number of nodes
			in.close();
		} catch(IOException e) {
			System.out.println(e);
		}
		Arrays.sort(graph);
		arcs= graph.length;
		to= new int[arcs];
		dist= new int[arcs];
		for (int i=0; i < arcs; i++) {
			to[i]= graph[i].dest;
			dist[i]= graph[i].cost;
		}

		// Create array H from the array of Arcs. Length= nodes+1 (sentinel)
		H= new int[nodes+1];
		int prevOrigin= -1;
		for (int i=0; i < arcs; i++) {
			int o= graph[i].origin;
			if (o != prevOrigin) {
				for (int j= prevOrigin+1; j < o; j++)
					H[j]= i;	// Nodes with no arcs out
				H[o]= i;
				prevOrigin= o;
			}
		}
		H[nodes]= arcs;		// Sentinel
		for (int i= nodes-1; i > 0; i--) {	// If last node has no arcs out, set its H
			if (H[i]==0)
				H[i]= arcs;
			else
				break;
		}
	}
	
	public Arc[] readData(BufferedReader in) throws IOException {
		int n= Integer.parseInt(in.readLine());
		Arc[] arcArr= new Arc[n];
		for (int i=0; i < n; i++) {
			arcArr[i]= new Arc();
			String str = in.readLine();
			StringTokenizer t = new StringTokenizer(str, ",");
			arcArr[i].origin= (Integer.parseInt(t.nextToken()));
			arcArr[i].dest= (Integer.parseInt(t.nextToken()));
			arcArr[i].cost= (Integer.parseInt(t.nextToken()));
			if (arcArr[i].origin > nodes)
				nodes= arcArr[i].origin;
			if (arcArr[i].dest > nodes)
				nodes= arcArr[i].dest;
		}
		nodes++;		// Started at 0, add one to get number of nodes
		return arcArr;
	}
	
	// Assumes traverse starts at node 0. Traverse all arcs once.
	// This visits nodes more than once. Create boolean array visit[nodes];
	// set it to true when node is visited;
	// and check it to output all nodes in network only once.
	public void traverse() {
		for (int node= 0; node < nodes; node++) {
			for (int arc= H[node]; arc < H[node+1]; arc++)
				System.out.println("("+ node +
						", "+ to[arc]+", "+ dist[arc]+")");
		}
	}
	
    public void print() {
    	System.out.println("i \tP \tD");
    	for (int i=0; i < nodes; i++) {
    		if (P[i] == Short.MIN_VALUE)
    			System.out.println(i + "\t- \t" + D[i]);
    		else
				System.out.println(i + "\t" + P[i] + "\t" + D[i]);
    	}
    }
    
    public void shortDEP(int root) {
        final int MAX_COST= Integer.MAX_VALUE/2;    // 'Infinite' initial value
        final int EMPTY= Short.MIN_VALUE;           // Flag for no value: -32767
        final int NEVER_ON_CL= -1;                  // Node never on CL before
        final int ON_CL_BEFORE= -2;                 // Node on CL before
        final int END_OF_CL= Integer.MAX_VALUE;     // Sentinel for end of CL; larger than max node number
        
		D= new int[nodes];                    		// Distance from root
		P= new int[nodes];                    		// Predecessor node from root
        int[] CL= new int[nodes];                   // Candidate list position
        
        for (int i=0; i < nodes; i++) {             // Initialize all nodes
            D[i]= MAX_COST;                         // Initial label-> infinity
            P[i]= EMPTY;                            // No predecessor on path
            CL[i]= NEVER_ON_CL;                     // Never on candidate list
        }
        
        // Initialize root node
        D[root]= 0;                                 // Root is 0 distance from root
        CL[root]=  END_OF_CL;                       // Put root at end of CL
        int lastOnList= root;
        int firstNode= root;
        
        do {
            int Dfirst= D[firstNode];                   // Shortcut for D[firstNode]
            // Check through all links out of "node"
            for (int link= H[firstNode]; link < H[firstNode+1]; link++) {
                int outNode= to[link];
                int DoutNode= Dfirst+ dist[link];       // Dist to node via first node in CL
                if (DoutNode < D[outNode]) {            // If this is an improvement
                    P[outNode]= firstNode;              // Record new predecessor
                    D[outNode]= DoutNode;               // Update for shorter distance
                    int CLoutNode= CL[outNode];         // Add node to CL
                    // Only differences are in next if-else
                    if (CLoutNode == NEVER_ON_CL) {     // See if node has been on CL before
                        CL[lastOnList]= outNode;        // If node has never been on CL, add it to the end
                        lastOnList= outNode;
                        CL[outNode]= END_OF_CL;
                    }
                    else if (CLoutNode == ON_CL_BEFORE) {   // If node was on CL before, add at front of CL
                        CL[outNode]= CL[firstNode];
                        CL[firstNode]= outNode;
                    }
                }
            }
            int nextCL= CL[firstNode];
            CL[firstNode]= ON_CL_BEFORE;
            firstNode= nextCL;
        } while (firstNode < END_OF_CL);
    }
    
    public void shortHK(int root) {
        final int MAX_COST= Integer.MAX_VALUE/2;    // 'Infinite' initial value
        final int EMPTY= Short.MIN_VALUE;           // Flag for no value: -32767
        final int NEVER_ON_CL= -1;                  // Node never on CL before
        final int ON_CL_BEFORE= -2;                 // Node on CL before
        final int END_OF_CL= Integer.MAX_VALUE;     // Sentinel for end of CL; larger than max node number
        
        D= new int[nodes];                    		// Distance from root
        P= new int[nodes];                    		// Predecessor node from root
        int[] CL= new int[nodes];                   // Candidate list position
        
        for (int i=0; i < nodes; i++) {             // Initialize all nodes
            D[i]= MAX_COST;                         // Initial label-> infinity
            P[i]= EMPTY;                            // No predecessor on path
            CL[i]= NEVER_ON_CL;                     // Never on candidate list
        }
        
        // Initialize root node
        D[root]= 0;                                 // Root is 0 distance from root
        CL[root]=  END_OF_CL;                       // Put root at end of CL
        int lastOnList= root;
        int firstNode= root;
        
        do {
            int Dfirst= D[firstNode];                   // Shortcut for D[firstNode]
            // Check through all links out of "node"
            for (int link= H[firstNode]; link < H[firstNode+1]; link++) {
                int outNode= to[link];
                int DoutNode= Dfirst+ dist[link];       // Dist to node via first node in CL
                if (DoutNode < D[outNode]) {            // If this is an improvement
                    P[outNode]= firstNode;              // Record new predecessor
                    D[outNode]= DoutNode;               // Update for shorter distance
                    int CLoutNode= CL[outNode];         // Add node to CL
                    // Only differences are in next if-else
                    if (CLoutNode == NEVER_ON_CL || CLoutNode == ON_CL_BEFORE) {     // See if node has been on CL before
                        int CLfirstNode= CL[firstNode];
                        if (CLfirstNode != END_OF_CL &&
                        (CLoutNode == ON_CL_BEFORE || DoutNode < D[CLfirstNode])){   // Add to front
                            CL[outNode]= CLfirstNode;
                            CL[firstNode]= outNode;
                        }
                        else {                          // Add to rear of CL
                            CL[lastOnList]= outNode;    // If node has never been on CL, add it to the end
                            lastOnList= outNode;
                            CL[outNode]= END_OF_CL;
                        }
                    }
                }
            }
            int nextCL= CL[firstNode];
            CL[firstNode]= ON_CL_BEFORE;
            firstNode= nextCL;
        } while (firstNode < END_OF_CL);
    }
    
    public void shortDijkstra(int root) {
        final int MAX_COST= Integer.MAX_VALUE/2;    // 'Infinite' initial value
        final int EMPTY= Short.MIN_VALUE;           // Flag for no value: -32767
        
       	Heap g= new Heap(arcs);
		D= new int[nodes];                    		// Distance from root
		P= new int[nodes];                    		// Predecessor node from root
        
        for (int i=0; i < nodes; i++) {             // Initialize all nodes
            D[i]= MAX_COST;                         // Initial label-> infinity
            P[i]= EMPTY;                            // No predecessor on path
        }
        
		MSTArc inArc= null;
        D[root]= 0;                                 // Root is 0 distance from root
        P[root]= 0;									// Root is its own predecessor
		
		for (int arc= H[root]; arc< H[root+1]; arc++)
			g.insert(new MSTArc(root, to[arc], dist[arc]));
		
		for (int i = 0; i < nodes-1; i++) {	
			do {
				if (g.getSize()==0) return;		// If heap empty (no more arcs), we're done
				inArc= (MSTArc) g.delete();		// Else get arc with destination with min cost from root
			} while (P[inArc.to]!= EMPTY);		// "To" node cannot be in tree already	
			int inNode= inArc.to;				// Node added to shortest path tree
			P[inNode]= inArc.from;				// Its predecessor is "from" node
			D[inNode]= inArc.dist; 				// Distance from root (see heap insert below)
			// Add arcs to heap from newly added node, with the labels of their "to" node
			for (int arc= H[inNode]; arc< H[inNode+1]; arc++)
				g.insert(new MSTArc(inNode, to[arc], D[inNode] + dist[arc]));
		}
    }

    public static void main(String[] args) {
    	Graph network= new Graph("src/greedy/graph2.txt");
    	System.out.println("Traverse");
    	network.traverse();
    	System.out.println("\nDEP shortest path, root 0");
    	network.shortDEP(0);
    	network.print();
    	System.out.println("\nHK shortest path, root 0");
    	network.shortHK(0);
    	network.print();
    	System.out.println("\nDijkstra shortest path, root 0");
    	network.shortDijkstra(0);
    	network.print();
    }
}