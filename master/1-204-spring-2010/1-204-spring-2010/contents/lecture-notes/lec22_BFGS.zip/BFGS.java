package src.bfgs;

public class BFGS {	
	private MathFunction4 funcObj;
	private int iter;		// Output- number of iterations
	private double gtol;	// Tolerance for convergence
	private double[] g;		// Gradient
	// The following are constants for consistency with Numerical Recipes. Some are problem-specific.
	private static final int ITMAX= 200;		// Max allowed iterations
	private static final double EPS= 1E-08;		// Machine precision. May want to use 1E-14 or so.
	private static final double TOLX= 4*EPS;	// Convergence criterion on x values. Use same TOLX for linsrch and dfpmin
	private static final double STPMX= 0.2;		// Scaled maximum step length allowed in line searches. This was 100.0 in Numerical Recipes. Problem-specific.
	private static final double ALF= 1E-4;		// linsrch average function value change parameter.
	
	public BFGS(MathFunction4 funcObj, double gtol) {
		this.funcObj= funcObj;
		this.gtol= gtol;
		// Gradient g allocated in dfpmin, where we know its size
	}
	
	public int getIter() {		// Returns number of iterations used to find solution
		return iter;
	}
	
	public double lnsrch(double[] xold, double fold, double[] p, double[] x, double stpmax) {
		double f;
		int n= xold.length;
		double slope= 0.0;
		double sum= 0.0;
		double alam2= 0.0;
		double f2= 0.0;
		for (int i= 0; i < n; i++)
			sum += p[i]*p[i];
		sum= Math.sqrt(sum);
		if (sum > stpmax)
			for (int i= 0; i < n; i++)
				p[i] *= stpmax/sum;		// Scale if attempted step is too big
		for (int i= 0; i < n; i++)
			slope += g[i]*p[i];
		if (slope >= 0.0)
			throw new ArithmeticException("Roundoff problem in lnsrch");
		double test= 0.0;
		for (int i= 0; i < n; i++) {
			double temp= Math.abs(p[i])/Math.max(Math.abs(xold[i]), 1.0);
			if (temp > test)
				test= temp;
		}
		double alamin= TOLX/test;		// Minimum step length
		double alam= 1.0;				// Always try full Newton step first
		do {
			for (int i= 0; i < n; i++)
				x[i]= xold[i] + alam*p[i];
			f= funcObj.func(x);
			double tmplam;
			if (alam < alamin) {		// Convergence on delta x
				for (int i= 0; i < n; i++) 
					x[i]= xold[i];
				return f;
			} else if (f <= fold + ALF*alam*slope)	// Sufficient function decrease
				return f;
			else {						// Backtrack
				if (alam == 1.0)		// First time through loop
					tmplam= -slope/(2.0*(f - fold - slope));
				else {					// Subsequent backtracks
					double rhs1= f - fold - alam*slope;
					double rhs2= f2 - fold - alam2*slope;
					double a= (rhs1/(alam*alam) - rhs2/(alam2*alam2))/(alam - alam2);
					double b= (-alam2*rhs1/(alam*alam)+ alam*rhs2/(alam2*alam2))/(alam - alam2);
					if (a == 0.0)
						tmplam= -slope/(2.0*b);
					else {
						double disc= b*b - 3.0*a*slope;
						if (disc < 0.0)
							tmplam= 0.5*alam;
						else if (b <= 0.0)
							tmplam= (-b + Math.sqrt(disc))/(3.0*a);
						else
							tmplam= -slope/(b+Math.sqrt(disc));
					}
					if (tmplam > 0.5*alam)
						tmplam= 0.5*alam;
				}
			}
			alam2= alam;
			f2= f;
			alam= Math.max(tmplam, 0.1*alam);
		} while (true);
	}
	
	public double dfpmin(double[] p) {	// Argument is initial point. This also returns the solution point
		double sum= 0.0;
		int n= p.length;
		double[] dg= new double[n];
		double[] hdg= new double[n];
		g= new double[n];
		double[] pnew= new double[n];
		double[] xi= new double[n];
		double[][] hessian= new double[n][n];
		double fp= funcObj.func(p);		// Calculate starting function value
		g= funcObj.df(p);				// and gradient
		for (int i= 0; i < n; i++) {
			hessian[i][i]= 1.0;			// Initialize inverse Hessian to unit matrix
			xi[i]= -g[i];				// Initial line direction
			sum += p[i]*p[i];
		}
		double stpmax= STPMX*Math.max(Math.sqrt(sum), (double)n);
		for (int its= 0; its < ITMAX; its++) {
			iter= its;
			fp= lnsrch(p, fp, xi, pnew, stpmax);
			for (int i= 0; i < n; i++) {
				xi[i]= pnew[i] - p[i];	// Update line direction
				p[i]= pnew[i];
			}
			double test= 0.0;			// Test convergence on delta x
			for (int i= 0; i < n; i++) {
				double temp= Math.abs(xi[i]/Math.max(Math.abs(p[i]), 1.0));
				if (temp > test)
					test= temp;
			}
			if (test < TOLX) 
				return fp;
			for (int i= 0; i < n; i++)	// Save old gradient
				dg[i]= g[i];			// Replace with System.arraycopy()
			g= funcObj.df(p);			// Get new gradient
			test= 0.0;
			double den= Math.max(fp, 1.0);
			for (int i= 0; i < n; i++) {
				double temp= Math.abs(g[i])*Math.max(Math.abs(p[i]), 1.0)/den;
				if (temp > test)
					test= temp;
			}
			if (test < gtol)
				return fp;
			for (int i= 0; i < n; i++)	// Compute difference in gradients
				dg[i]= g[i] - dg[i];
			for (int i= 0; i < n; i++) {
				hdg[i]= 0.0;
				for (int j= 0; j < n; j++)
					hdg[i] += hessian[i][j]*dg[j];
			}
			double fac, fae, sumdg, sumxi;
			fac= fae= sumdg= sumxi= 0.0;
			for (int i= 0; i < n; i++) {
				fac += dg[i]*xi[i];
				fae += dg[i]*hdg[i];
				sumdg += dg[i]*dg[i];
				sumxi += xi[i]*xi[i];
			}
			if (fac > Math.sqrt(EPS*sumdg*sumxi)) {	// Skip update if fac not sufficiently positive
				fac= 1.0/fac;
				double fad= 1.0/fae;
				for (int i= 0; i < n; i++)
					dg[i]= fac*xi[i] - fad*hdg[i];
				for (int i= 0; i < n; i++) {
					for (int j= i; j < n; j++) {
						hessian[i][j] += fac*xi[i]*xi[j] - fad*hdg[i]*hdg[j] + fae*dg[i]*dg[j];
						hessian[j][i] = hessian[i][j]; 
					}
				}
			}
			for (int i= 0; i < n; i++) {
				xi[i]= 0.0;
				for (int j= 0; j < n; j++)
					xi[i] -= hessian[i][j]*g[j]; 
			}
		}
		throw new ArithmeticException("Too many iterations in dfpmin");
	}
}