package src.bfgs;

public interface MathFunction4 {
	public double func(double[] x);		// Returns function value
	public double[] df(double[] x);		// Returns gradient 
}
