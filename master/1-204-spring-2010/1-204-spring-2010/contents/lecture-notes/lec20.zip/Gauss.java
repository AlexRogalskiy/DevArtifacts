package src.linear;

public class Gauss {
	public static double[] gaussian(double[][] a, double[] b) {
		int n = a.length; 				// Number of unknowns
		double[][] q = new double[n][n + 1];

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) 	// Form q matrix
				q[i][j]= a[i][j];
			q[i][n]= b[i];
		}
		forward_solve(q); 					// Do Gaussian elimination
		back_solve(q); 						// Perform back substitution

		double[] x= new double[n];			// Extract column n of q,
		for (int i = 0; i < n; i++)			// which contains the solution x
			x[i]= q[i][n];
		return x;
	}

	private static void forward_solve(double[][] q) {
		int n = q.length;
		int m= q[0].length;

		for (int i = 0; i < n; i++) { 		// Find row w/max element in this
			int maxRow = i; 				// column, at or below diagonal
			for (int k = i + 1; k < n; k++)
				if (Math.abs(q[k][i]) > Math.abs(q[maxRow][i]))
					maxRow = k;

			if (maxRow != i) 				// If row not current row, swap
				for (int j = i; j < m; j++) {
					double t = q[i][j]; 
					q[i][j]= q[maxRow][j];
					q[maxRow][j]= t;
				}

			for (int j = i + 1; j < n; j++) { 	// Calculate pivot ratio
				double pivot = q[j][i] / q[i][i];
				for (int k = i; k < m; k++) 	// Pivot operation itself
					q[j][k] -= q[i][k] * pivot;
			}
		}
	}

	private static void back_solve(double[][] q) {
		int n = q.length;
		int m= q[0].length;
		for (int p= n; p < m; p++) {				// Added loop over p; executes only once in gaussian()
			for (int j = n - 1; j >= 0; j--) { 		// Start at last row
				double t = 0.0; 					// t- temporary
				for (int k = j + 1; k < n; k++)
					t += q[j][k] * q[k][p]; 
				q[j][p]= (q[j][p] - t) / q[j][j];
			}
		}
	}
	
	public static double[][] invert(double[][] a) {
		int n = a.length; 					// Number of unknowns
		double[][] q = new double[n][n+n];

		for (int i = 0; i < n; i++) 
			for (int j = 0; j < n; j++) 	// Form q matrix
				q[i][j]= a[i][j];
		// Form identity matrix in right half of q
		for (int i = 0; i < n; i++) 
			q[i][n+i]= 1.0;

		forward_solve(q); 					// Do Gaussian elimination
		back_solve(q); 						// Perform back substitution

		double[][] x= new double[n][n];		// Extract right half of q
		for (int i = 0; i < n; i++)			// which contains the inverse
			for (int j= 0; j < n; j++)
				x[i][j]= q[i][j+n];
		return x;
	}

	public static double[][] multiply(double[][] a, double[][] b) {
		double[][] result= null;
		int nrows = a.length;
		int p = a[0].length;
		if(p == b.length) {
			result = new double[nrows][b[0].length];
			for(int i=0; i<nrows; i++)
				for(int j=0; j<result[0].length; j++) {
					double t = 0.0;
					for(int k=0; k<p; k++) {
						t += a[i][k] * b[k][j];
					}
					result[i][j]= t;
				}
		}
		return result;
	}
}  