package src.linear;
import javax.swing.*;

public class GaussTest {

	public static void main(String[] args) {
		double term;
		String input = JOptionPane.showInputDialog("Enter number of unknowns");
		int n = Integer.parseInt(input);
		// Create matrices a, b
		double[][] a = new double[n][n];
		double[] b = new double[n];
		// Enter matrix a
		for (int i = 0; i < a.length; i++)
			for (int j = 0; j < a.length; j++) {
				input =JOptionPane.showInputDialog("Enter a[" + i + "][" + j + "]");
				term = Double.parseDouble(input);
				a[i][j]=  term;
			}
		//		Enter vector b as 1-column matrix
		for (int i = 0; i < b.length; i++) {
			input = JOptionPane.showInputDialog("Enter b[" + i + "]");
			term = Double.parseDouble(input);
			b[i]= term;
		}
		
		double[] x= Gauss.gaussian(a, b);
		
		System.out.println("Matrix a:");
		for(int i=0; i< a.length; i++) {
            for(int j=0; j< a[0].length; j++)
                System.out.print(a[i][j] + " ");
            System.out.println();
        }
		System.out.println();
		System.out.println("Vector b:");
		for(int i=0; i< b.length; i++) 
			System.out.println(b[i]);
		System.out.println();
		System.out.println("Solution vector x:");
		for(int i=0; i< x.length; i++) 
			System.out.println(x[i]);
		
		double[][] inverse= Gauss.invert(a);
		System.out.println("\nInverse");
		for(int i=0; i< a.length; i++) {
            for(int j=0; j< a[0].length; j++)
                System.out.print(inverse[i][j] + " ");
            System.out.println();
        }
		
		System.out.println("Matrix a:");
		for(int i=0; i< a.length; i++) {
            for(int j=0; j< a[0].length; j++)
                System.out.print(a[i][j] + " ");
            System.out.println();
        }
		System.out.println();
		
		double[][] result= Gauss.multiply(a, inverse);
		System.out.println("a * a inverse");
		for(int i=0; i< a.length; i++) {
            for(int j=0; j< a[0].length; j++)
                System.out.print(result[i][j] + " ");
            System.out.println();
        }
	}
}