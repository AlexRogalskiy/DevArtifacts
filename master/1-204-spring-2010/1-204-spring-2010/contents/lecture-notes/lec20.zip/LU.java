package src.linear;

public class LU {
	int n;				// Number of equations
	double[][] lu;		// LU decomposition (output)
	int[] indx;			// Permutations of rows are tracked by indx
	double d;			// +1 or -1; needed to compute determinant
	double[][] aref;	// Original A matrix, used only in improve()
	
	LU(double[][] a) {
		n= a.length;
		lu= a;
		aref= new double[n][n];
		// Can't use System.arraycopy() on 2-D arrays; it does a shallow copy on the rows only
		for (int i= 0; i < n; i++)
			for (int j= 0; j < n; j++)
				aref[i][j]= a[i][j];
		indx= new int[n];
		
		final double TINY= 1E-40;
		int imax= -1;		// NR doesn't initialize imax
		double[] vv= new double[n];
		d= 1.0;
		for (int i= 0; i < n; i++) {
			double big= 0.0;
			for (int j= 0; j <  n; j++) {
				double temp= Math.abs(lu[i][j]);
				if (temp > big) big= temp;
			}
			if (big == 0.0)
				throw new IllegalArgumentException("Singular matrix");
			vv[i]= 1.0/big;
		}
		for (int k= 0; k < n; k++) {
			double big= 0.0;
			for (int i= k; i < n; i++) {
				double temp= vv[i]*Math.abs(lu[i][k]);
				if (temp > big) {
					big= temp;
					imax= i;
				}
			}
			if (k != imax) {
				for (int j= 0; j < n; j++) {
					double temp= lu[imax][j];
					lu[imax][j]= lu[k][j];
					lu[k][j]= temp;
				}
				d= -d;
				vv[imax]= vv[k];
			}
			indx[k]= imax;
			if (lu[k][k] == 0.0)
				lu[k][k]= TINY;
			for (int i= k+1; i < n; i++) {
				double temp= lu[i][k] /= lu[k][k];
				for (int j= k+1; j < n; j++)
					lu[i][j] -= temp*lu[k][j];
			}
		}
	}
	public double[] solve(double[] b) {
		int ii= 0;
		double[] x= new double[n];
		if (b.length != n)
			throw new IllegalArgumentException("b wrong size");
		System.arraycopy(b, 0, x, 0, n);
		for (int i= 0; i < n; i++) {
			int ip= indx[i];
			double sum= x[ip];
			x[ip]= x[i];
			if (ii != 0)
				for (int j= ii-1; j < i; j++)
					sum -= lu[i][j]*x[j];
			else if (sum != 0.0)
				ii = i+1;
			x[i]= sum;
		}
		for (int i= n-1; i>=0; i--) {
			double sum= x[i];
			for (int j= i+1; j < n; j++)
				sum -= lu[i][j]*x[j];
			x[i]= sum/lu[i][i];
		}
		return x;
	}
	
	public double[][] solve(double[][] b) {
		int m= b[0].length;
		if (b.length != n)
			throw new IllegalArgumentException("b wrong size");
		double[][] x= new double[n][m];
		double[] xx= new double[n];
		for (int j= 0; j < m; j++) {
			for (int i= 0; i < n; i++)
				xx[i]= b[i][j];
			xx= solve(xx);
			for (int i= 0; i < n; i++)
				x[i][j]= xx[i];
		}
		return x;
	}
	
	public double[][] inverse() {
		double[][] ainv= new double[n][n];
		for (int i= 0; i < n; i++)
			ainv[i][i]= 1.0;
		return solve(ainv);
	}
	
	public double determinant() {
		double dd= d;
		for (int i= 0; i < n; i++)
			dd *= lu[i][i];
		return dd;
	}
	public double[] improve(double[] b, double[] x) {
		double[] r= new double[n];
		for (int i= 0; i < n; i++) {
			double sdp= -b[i];
			for (int j= 0; j < n; j++)
				sdp += aref[i][j] * x[j];
			r[i]= sdp;
		}
		r= solve(r);
		for (int i= 0; i < n; i++)
			x[i] -= r[i];
		return x;
	}
}