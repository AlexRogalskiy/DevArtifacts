package src.linear;
import java.io.*;
import java.util.StringTokenizer;

public class RailDelay {
	private int n;						// Number of train classes  (eastbound/westbound passenger, thru freight, wayfreight yields 6)
	private int d;						// Distance in miles
	private int b;						// Number of sidings
	private double[][] p;				// Probability of delay in interaction
	private double[] s;					// Time to take siding (minutes), by train class
	private double[] v;					// Direction flag (-1 or +1), by train class
	private double[][] c;				// Matrix that indicates if interaction is pass or meet, by train classes involved
	private int[] nTrain;				// Number of trains by class, per day
	
	public RailDelay(String filename) {
		try {
			FileReader fin= new FileReader(filename);
			BufferedReader in= new BufferedReader(fin);
			n= Integer.parseInt(in.readLine());
			d= Integer.parseInt(in.readLine());
			b= Integer.parseInt(in.readLine());
			
			p= new double[n][n];
			for (int i= 0; i < n; i++) {
				String str = in.readLine();
				StringTokenizer t = new StringTokenizer(str, " ");
				for (int j= 0; j < n; j++) 
					p[i][j]= Double.parseDouble(t.nextToken());
			}
			s= new double[n];
			String str = in.readLine();
			StringTokenizer t = new StringTokenizer(str, " ");
			for (int i= 0; i < n; i++) 
				s[i]= Double.parseDouble(t.nextToken());
			
			v= new double[n];
			str = in.readLine();
			t = new StringTokenizer(str, " ");
			for (int i= 0; i < n; i++) 
				v[i]= Double.parseDouble(t.nextToken());
			
			c= new double[n][n];
			for (int i= 0; i < n; i++) {
				str = in.readLine();
				t = new StringTokenizer(str, " ");
				for (int j= 0; j < n; j++) 
					c[i][j]= Double.parseDouble(t.nextToken());
			}
			
			nTrain= new int[n];
			str = in.readLine();
			t = new StringTokenizer(str, " ");
			for (int i= 0; i < n; i++) 
				nTrain[i]= Integer.parseInt(t.nextToken());
			
			in.close();
		} catch(IOException e) {
			System.out.println(e);
		}
	}
	
	public double[] getDelay() {
		double[][] dm= new double[n][n];			// Delay matrix D
		for (int i= 0; i < n; i++)
			for (int j= 0; j < n; j++) {			// Modify the eqn to multiply si by pij. Error in paper
				dm[i][j]= p[i][j]*s[i] + 60.0*p[i][j]*p[i][j]*Math.abs(d/v[i]- d/v[j])/(2.0*(b+1));
			}
		System.out.println("D");
		for (int i= 0; i < n; i++) {
			for (int j= 0; j < n; j++) {	
				System.out.printf("%7.3f",dm[i][j]);
			}
			System.out.println();
		}
		
		double[] t= new double[n];
		for (int i= 0; i < n; i++)
			t[i]= d*60.0/v[i];
		
		double[][] a= new double[n][n];				// Total delay matrix A
		for (int i= 0; i < n; i++) {
			double delay= 0.0;
			for (int j= 0; j < n; j++) {
				if (i != j) {
					a[i][j]= dm[i][j]*nTrain[j]*c[i][j]/1440;
					delay += a[i][j];
				}
			}
			a[i][i]= 1.0 - delay;
		}
		System.out.println("\nA");
		for (int i= 0; i < n; i++) {
			for (int j= 0; j < n; j++) {	
				System.out.printf("%7.3f ",a[i][j]);
			}
			System.out.println();
		}
		System.out.println();
		
		double[] w= Gauss.gaussian(a, t);
		return w;
	}
	
	public double getFreeTime(int i) {
		return d*60.0/v[i];
	}
	
	public static void main(String[] args) {
		RailDelay r= new RailDelay("src/linear/rail.txt");
		double[] w= r.getDelay();
		int n= w.length;
		System.out.println("i Act time Free time");
		for (int i= 0; i < n; i++)
			System.out.printf("%d %8.1f %8.1f \n",i, Math.abs(w[i]), Math.abs(r.getFreeTime(i)));
		System.out.println();	
	}
}