package src.linear;

public class LUTest {
	public static void main(String[] args) {
		double[][] a= { 
				{3, 1, -2},
				{2, 4, 3},
				{1, -3, 0}
		};
		System.out.println("Matrix a:");
		for(int i=0; i< a.length; i++) {
            for(int j=0; j< a[0].length; j++)
                System.out.print(a[i][j] + " ");
            System.out.println();
        }		
		double[] b= {5, 35, -5};		
		LU matrix= new LU(a);

		System.out.println("\nLU(a):");
		for(int i=0; i< a.length; i++) {
            for(int j=0; j< a[0].length; j++)
                System.out.print(a[i][j] + " ");
            System.out.println();
        }
		System.out.println();
		System.out.println("Vector b:");
		for(int i=0; i< b.length; i++) 
			System.out.println(b[i]);
		System.out.println();
		
		double[] x= matrix.solve(b);
		System.out.println("Solution vector x:");
		for(int i=0; i< x.length; i++) 
			System.out.println(x[i]);
		
		double[] ximproved= matrix.improve(b, x);
		System.out.println("\nImproved solution vector x:");
		for(int i=0; i< x.length; i++) 
			System.out.println(ximproved[i]);
		
		double[][] xinv= matrix.inverse();
		System.out.println("\nInverse");
		for(int i=0; i< a.length; i++) {
            for(int j=0; j< a[0].length; j++)
                System.out.print(xinv[i][j] + " ");
            System.out.println();
        }
		
		double determinant= matrix.determinant();
		System.out.println("\nDeterminant: " + determinant);
	}
}