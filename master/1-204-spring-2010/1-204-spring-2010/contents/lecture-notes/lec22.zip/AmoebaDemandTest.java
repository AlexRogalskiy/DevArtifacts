package src.amoeba;

public class AmoebaDemandTest {
	public static void main(String[] args) {
		double[][] x= { {1, 52.9 - 4.4},
				{1, 4.1 - 28.5},
				{1, 4.1 - 86.9},
				{1, 56.2 - 31.6},
				{1, 51.8 - 20.2},
				{1, 0.2 - 91.2},
				{1, 27.6 - 79.7},
				{1, 89.9 - 2.2},
				{1, 41.5 - 24.5},
				{1, 95.0 - 43.5},
				{1, 99.1 - 8.4},
				{1, 18.5 - 84.0},
				{1, 82.0 - 38.0},
				{1, 8.6 - 1.6},
				{1, 22.5 - 74.1},
				{1, 51.4 - 83.8},
				{1, 81.0 - 19.2},
				{1, 51.0 - 85.0},
				{1, 62.2 - 90.1},
				{1, 95.1 - 22.2},
				{1, 41.6 - 91.5}
		};
		double[] y= {0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1};

		DemandModelAmoeba d= new DemandModelAmoeba(x, y);
		double[] beta= {0, 0};						// Initial guess
		double log0= d.func2(beta);
		double[] initialPoint= {0.0, 0.0};
		double initialDelta= 0.1;
		double ftol= 1E-14;
		Amoeba a= new Amoeba(ftol);
		beta= a.minimize(initialPoint, initialDelta, d);
		double logB= d.func2(beta);
		double[][] jacobian= d.jacobian(beta);
		d.print(log0, logB, beta, jacobian);
	}
}