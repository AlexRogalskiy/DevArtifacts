package src.amoeba;

public interface MathFunction3 {
	double func2(double[] x);
}
