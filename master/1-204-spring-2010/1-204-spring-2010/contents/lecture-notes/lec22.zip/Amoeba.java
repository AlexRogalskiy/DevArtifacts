package src.amoeba;

public class Amoeba {
	private double ftol;
	private int nfunc;		// Number of function evaluations
	private int mpts;
	private int ndim;
	private double fmin;	// Function value at minimum
	private double[] y;		// Function values at vertices of simplex
	private double[][] p;	// Current simplex
	
	public Amoeba(double ftol) {
		this.ftol= ftol;
	}
	
	public double[] minimize(double[] point, double del, MathFunction3 mf3) {
		double[] dels= new double[point.length];
		for (int i= 0; i < point.length; i++)
			dels[i]= del;
		return minimize(point, dels, mf3);
	}
	
	public double[] minimize(double[] point, double[] dels, MathFunction3 mf3) {
		int ndim= point.length;
		double[][] pp= new double[ndim+1][ndim];
		for (int i= 0; i < ndim + 1; i++) {
			for (int j= 0; j < ndim; j++)
				pp[i][j]= point[j];
			if (i != 0) 
				pp[i][i-1] += dels[i-1];
		}
		return minimize(pp, mf3);
	}
	
	public double[] minimize(double[][] pp, MathFunction3 mf3) {
		final int NMAX= 5000;		// Maximum number of function evaluations
		final double TINY= 1E-10;
		int ihi, ilo, inhi;
		mpts= pp.length;
		ndim= pp[0].length;
		double[] pmin= new double[ndim];
		double[] x= new double[ndim];
		p= pp;
		y= new double[mpts];
		for (int i= 0; i < mpts; i++) {
			for (int j= 0; j < ndim; j++) 
				x[j]= p[i][j];
			y[i]= mf3.func2(x);
		}
		nfunc= 0;
		double[] psum= getPsum(p);
		while (true) {
			ilo= 0;
			// ihi= y[0] > y[1] ? (inhi= 1, 0) : (inhi= 0, 1);
			if (y[0] > y[1]) {
				inhi= 1;
				ihi= 0;
			} else {
				inhi= 0;
				ihi= 1;
			}
			for (int i= 0; i < mpts; i++) {
				if (y[i] <= y[ilo])
					ilo= i;
				if (y[i] > y[ihi]) {
					inhi= ihi;
					ihi= i;
				} else if (y[i] > y[inhi] && i != ihi)
					inhi= i;
			}
			double rtol= 2.0 * Math.abs(y[ihi] - y[ilo])/( Math.abs(y[ihi]) + Math.abs(y[ilo]) + TINY);
			if (rtol < ftol) {
				// swap y[0] and y[ilo]
				double t= y[0];
				y[0]= y[ilo];
				y[ilo]= t;
				for (int i= 0; i < ndim; i++) {
					// swap p[0][i] and p[ilo][i]
					double tt= p[0][i];
					p[0][i]= p[ilo][i];
					p[ilo][i]= tt;
					pmin[i]= p[0][i];
				}
				fmin= y[0];
				return pmin;
			}
			if (nfunc >= NMAX) throw new RuntimeException("NMAX exceeded");		// Create new Exception type 
			nfunc += 2;
			System.out.println("Function evaluations a: " + nfunc);				// Demo output for class use
			double ytry= amotry(p, y, psum, ihi, -1.0, mf3);
			if (ytry <= y[ilo])
				ytry= amotry(p, y, psum, ihi, 2.0, mf3);
			else if (ytry >= y[inhi]) {
				double ysave= y[ihi];
				ytry= amotry(p, y, psum, ihi, 0.5, mf3);
				if (ytry >= ysave) {
					for (int i= 0; i < mpts; i++) {
						if (i != ilo) {
							for (int j= 0; j < ndim; j++)
								p[i][j]= psum[j]= 0.5*(p[i][j]+p[ilo][j]);
							y[i]= mf3.func2(psum);
						}
					}
					nfunc += ndim;
					System.out.println("Function evaluations b: " + nfunc);				// Demo output for class use
					psum= getPsum(p);
				}
			} else
				--nfunc;
		}
	}
	
	private double[] getPsum(double[][] p) {
		double[] psum= new double[ndim];
		for (int j= 0; j < ndim; j++) {
			double sum= 0.0;
			for (int i= 0; i < mpts; i++) 
				sum += p[i][j];
			psum[j]= sum;
		}
		return psum;
	}
	
	private double amotry(double[][] p, double[] y, double[] psum, int ihi, double fac, MathFunction3 mf3) {
		double[] ptry= new double[ndim];
		double fac1= (1.0-fac)/ndim;
		double fac2= fac1 - fac;
		for (int j= 0; j < ndim; j++)
			ptry[j]= psum[j]*fac1 - p[ihi][j]*fac2; 
		double ytry= mf3.func2(ptry);
		if (ytry < y[ihi]) {
			y[ihi]= ytry;
			for (int j= 0; j < ndim; j++) {
				psum[j] += ptry[j] - p[ihi][j];
				p[ihi][j]= ptry[j];
			}
		}
		return ytry;
	}
	
	public double getFmin() {
		return fmin;
	}
}