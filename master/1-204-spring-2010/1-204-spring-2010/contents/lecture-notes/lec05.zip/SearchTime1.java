package src.divideconquer;
public class SearchTime1 {
	public static void timeSearch() {
		int a[] = new int[1001];
		int n[] = new int[21];
		for (int j = 1; j <= 1000; j++)
			a[j] = j;
		for (int j = 1; j <= 10; j++) {
			n[j] = 10 * (j - 1);
			n[j + 10] = 100 * j;
		}
		System.out.println("     n  time");
		for (int j = 1; j <= 20; j++) {
			long h = System.nanoTime();
			SimpleSearch.seqSearch(a, 0, n[j]);
			long h1 = System.nanoTime();
			long t = h1 - h;
			System.out.println("      " + n[j] + "      " + t);
		}
		System.out.println("Times are in nanoseconds");
	}

	public static void main(String[] args) {
		timeSearch();
	}
}
