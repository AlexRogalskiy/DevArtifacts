package src.divideconquer;
public class MatrixCount {
	static int count;

	public static double[][] add( double[][] a, double[][] b) {
		int m= a.length;
		int n= a[0].length;
		double[][] c = new double[m][n];
		for (int i = 0; i < m; i++) {
			count++; // For `for i'
			for (int j = 0; j < n; j++) {
				count++; // For `for j'
				c[i][j] = a[i][j] + b[i][j];
				count++; // For the assignment
			}
			count++; // For loop initialization and
			// last time of `for j'
		}
		count++; // For loop initialization and
		// last time of `for i'
		return c;
	}

	public static void main(String[] args) {
		count = 0;
		double[][] a = { {1, 2}, 
						{3, 4} };
		double[][] b = { {1, 2}, 
						{3, 4} };
		double[][] c = add(a, b);
		System.out.println(c[0][0]+" "+c[0][1]);
		System.out.println(c[1][0]+" "+c[1][1]);
		System.out.println("Count is: "+ count);
	}
}