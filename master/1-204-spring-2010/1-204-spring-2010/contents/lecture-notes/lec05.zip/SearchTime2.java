package src.divideconquer;
public class SearchTime2 {
	public static void timeSearch() { // Repetition factors (increase by 100 from textbook values)
		int[] r = { 0, 20000000, 20000000, 15000000, 10000000, 10000000, 10000000, 5000000,
				5000000, 5000000, 5000000, 5000000, 5000000, 5000000, 5000000, 5000000, 5000000,
				2500000, 2500000, 2500000, 2500000 };
		int a[] = new int[1001];
		int n[] = new int[21];
		for (int j = 1; j <= 1000; j++)
			a[j] = j;
		for (int j = 1; j <= 10; j++) {
			n[j] = 10 * (j - 1);
			n[j + 10] = 100 * j;
		}
		System.out.println("       n         t1              t\n");
		for (int j = 1; j <= 20; j++) {
			long h = System.nanoTime();
			for (int i = 1; i <= r[j]; i++) {
				SimpleSearch.seqSearch(a, 0, n[j]);
			}
			long h1 = System.nanoTime();
			long t1 = h1 - h;
			float t = t1;
			t /= r[j];
			System.out.println("      " + n[j] + "      " + t1 + "       " + t);
		}
		System.out.println("Times are in nanoseconds");
	}

	public static void main(String[] args) {
		timeSearch();
	}
}