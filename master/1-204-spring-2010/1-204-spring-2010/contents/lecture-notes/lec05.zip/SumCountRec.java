package src.divideconquer;

public class SumCountRec {
	static int count;

	// Assume n >= 0
	public static double rSum(double[] a, int n) {
		count++;
		if (n == 0) {
			count++;
			return 0.0;
		}
		else {
			count++;
			return rSum(a, n-1) + a[n-1];
		}
	}

	public static void main(String[] args) {
		count = 0;
		double[] a = { 1, 2, 3, 4, 5};
		System.out.println("Sum is " + rSum(a, a.length));
		System.out.println("Count is " + count);
	}
}
