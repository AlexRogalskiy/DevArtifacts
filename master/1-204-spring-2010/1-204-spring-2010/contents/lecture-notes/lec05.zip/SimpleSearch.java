package src.divideconquer;
public class SimpleSearch {
	public static int seqSearch(int[] a, int x, int n) {
		int i= n;
		a[0] = x;
		while (a[i] != x)
			i--;
		return i;
	}
	
	public static void main(String[] args) {
		// Slot 0 is a place-holder; search value copied there
		int[] a = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
		System.out.println("SeqSearch location is " + seqSearch(a, 7, a.length-1));
		System.out.println("SeqSearch location is " + seqSearch(a, 11, a.length-1));
	}
}