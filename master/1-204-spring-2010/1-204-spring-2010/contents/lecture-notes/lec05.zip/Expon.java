package src.divideconquer;

public class Expon {
	public static int count;
	public static long exponentiate(long x, long n) {
		count= 0;
		long answer = 1;
		while (n > 0) {
			while (n % 2 == 0) {
				n /= 2;
				x *= x;
				//System.out.println(" x: "+x+" n: "+n);
				count++;
			}
			n--;
			answer *= x;
			//System.out.println(" x: "+x+" n: "+n+" answer: "+answer);
			count++;
		}
		return answer;
	}

	public static void main(String[] args) {
		long myX = 5;
		for (long myN= 1; myN <= 25; myN++)
			System.out.println(myX +" to the "
					+myN+" power is " + exponentiate(myX, myN)+"\t\tCount: "+ count);
		System.out.println("Max long value     : "+Long.MAX_VALUE);
	}
}