package src.dataStructures;

public class Set {
	private int[] p;
	private static final int DEFAULT_CAPACITY = 10;

	public Set(int size) {
		p = new int[size];
		for (int i = 0; i < size; i++)
			p[i] = -1;
	}
	
	public Set() {
		this(DEFAULT_CAPACITY);
	}

	public void simpleUnion(int i, int j) {
		p[i] = j;
	}

	public int simpleFind(int i) {
		while (p[i] >= 0)
			i = p[i];
		return i;
	}

	public void weightedUnion(int i, int j) {
		// Could guard against invalid output by checking p[i]<0 and p[j] < 0 
		// and throwing exception if they are not.
		int nodes = p[i] + p[j];	// p[] are negative values
		if (p[i] > p[j]) {// i has fewer nodes
			p[i] = j;
			p[j] = nodes;
		} else { // j has fewer or equal nodes
			p[j] = i;
			p[i] = nodes;
		}
	}

	public int collapsingFind(int i) {
		int r = i;
		while (p[r] >= 0)
			r = p[r];
		while (i != r) { // Collapse nodes from i to root r
			int s = p[i];
			p[i] = r;
			i = s;
		}
		return r;
	}
	
	public static void main(String[] args) {
		// Implementation doesn't guard against non-disjoint (invalid) input
		System.out.println("Horowitz Fig 2.23");
		Set s= new Set();
		s.weightedUnion(1,2);
		s.weightedUnion(3,4);
		s.weightedUnion(5,6);
		s.weightedUnion(7,8);
		s.weightedUnion(1,3);
		s.weightedUnion(5,7);
		s.weightedUnion(1,5);
		for (int i= 1; i < 9; i++)
			System.out.print(" "+ s.p[i]);
		System.out.println();
		s.collapsingFind(8);
		for (int i= 1; i < 9; i++)
			System.out.print(" "+ s.p[i]);
		System.out.println();
		s.collapsingFind(6);
		for (int i= 1; i < 9; i++)
			System.out.print(" "+ s.p[i]);
		System.out.println();
	}
}