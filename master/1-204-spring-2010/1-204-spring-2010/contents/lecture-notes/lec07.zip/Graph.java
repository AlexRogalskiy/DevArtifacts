package src.dataStructures;
import java.io.*;
import java.util.*;

public class Graph {
	private int to[];
	private int dist[];
	private int H[];
	private int nodes;
	private int arcs;
	
	public Graph(String filename) {
		Arc[] graph= null;		// graph is discarded at end of constructor
		try {
			FileReader fin= new FileReader(filename);
			BufferedReader in= new BufferedReader(fin);
			graph= readData(in);	// also sets nbrNodes
			in.close();
		} catch(IOException e) {
			System.out.println(e);
		}
		Arrays.sort(graph);
		arcs= graph.length;
		to= new int[arcs];
		dist= new int[arcs];
		for (int i=0; i < arcs; i++) {
			to[i]= graph[i].dest;
			dist[i]= graph[i].cost;
		}

		// Create array H from the array of Arcs. Length= nodes+1 (sentinel)
		H= new int[nodes+1];
		int prevOrigin= -1;
		for (int i=0; i < arcs; i++) {
			int o= graph[i].origin;
			if (o != prevOrigin) {
				for (int j= prevOrigin+1; j < o; j++)
					H[j]= i;	// Nodes with no arcs out
				H[o]= i;
				prevOrigin= o;
			}
		}
		for (int i= nodes; i > prevOrigin; i--) 	// Sentinel, and nodes before it with no arcs out.
			H[i]= arcs;
	}
	
	public Arc[] readData(BufferedReader in) throws IOException {
		int n= Integer.parseInt(in.readLine());
		Arc[] arcArr= new Arc[n];
		for (int i=0; i < n; i++) {
			arcArr[i]= new Arc();
			String str = in.readLine();
			StringTokenizer t = new StringTokenizer(str, ",");
			arcArr[i].origin= (Integer.parseInt(t.nextToken()));
			arcArr[i].dest= (Integer.parseInt(t.nextToken()));
			arcArr[i].cost= (Integer.parseInt(t.nextToken()));
			if (arcArr[i].origin > nodes)
				nodes= arcArr[i].origin;
			if (arcArr[i].dest > nodes)
				nodes= arcArr[i].dest;
		}
		nodes++;		// Started at 0, add one to get number of nodes
		return arcArr;
	}
	
	// Assumes traverse starts at node 0. Traverse all arcs once.
	// This visits nodes more than once. Create boolean array visit[nodes];
	// set it to true when node is visited;
	// and check it to output all nodes in network only once.
	public void traverse() {
		for (int node= 0; node < nodes; node++) {
			for (int arc= H[node]; arc < H[node+1]; arc++)
				System.out.println("("+ node +
						", "+ to[arc]+", "+ dist[arc]+")");
		}
	}
    
    public static void main(String[] args) {
    	Graph g= new Graph("src/dataStructures/graph.txt");
    	g.traverse();
    }
}