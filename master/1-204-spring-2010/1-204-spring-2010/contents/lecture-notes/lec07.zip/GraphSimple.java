package src.dataStructures;

public class GraphSimple {
	public static void main(String[] args) {
		// Create graph
		int[] H= {0, 3, 4, 4, 6, 6};		// 5 actual nodes, numbers 0-4
		int[] to= {1, 2, 3, 2, 4, 1};		// 6 arcs, numbers 0-5
		int[] cost= {43, 52, 94, 22, 71, 37};
		int nodes= H.length - 1;			// Don't count sentinel

		for (int node= 0; node < nodes; node++) {
			for (int arc= H[node]; arc < H[node+1]; arc++)
				System.out.println("Arc from node " + node +
						" to node "+ to[arc] + " cost " + cost[arc]);
		}
	}
}  