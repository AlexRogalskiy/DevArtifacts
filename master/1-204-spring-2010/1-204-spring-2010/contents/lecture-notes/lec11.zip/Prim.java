package src.greedy;

public class Prim {		// Assumes connected graph; not checked
	private int nodes;	// Assumes consecutive node numbers
	private int[] head;
	private int[] to;
	private int[] dist;
	private int[] P; 				// Predecessor node back to root
	private boolean[] visited; 		// Has node been visited
	private int MSTcost;

	Prim(int n, int[] h, int[] t, int[] d) {
		nodes = n;
		head = h;
		to = t;
		dist = d;
	}

	public void print() {
		System.out.println("i \tP");
		for (int i = 0; i < nodes; i++) {
			if (P[i] == -1)
				System.out.println(i + "\t-");
			else
				System.out.println(i + "\t" + P[i]);
		}
		System.out.println("MST cost: " + MSTcost);
	}

	public int prim(int root) {
		P = new int[nodes]; 				// Predecessor node from root
		visited = new boolean[nodes]; 		// Has node been visited in algorithm
		for (int i = 0; i < nodes; i++) { 	// Initialize all nodes
			P[i] = -1; 						// No predecessor on path
		}
		visited[root] = true;				// Initialize root node

		for (int i = 0; i < nodes-1; i++) {		// Add nodes-1 arcs
			int minDist = Integer.MAX_VALUE;
			int nextNode = -1; 				// Next node to be added to MST
			int pred = -1; 					// Predecessor node of next node added to MST
			// Find node with shortest distance via arc from already visited set
			for (int node = 0; node < nodes; node++) {
				if (visited[node])
					for (int arc = head[node]; arc < head[node + 1]; arc++) {
						int dest = to[arc];
						if (!visited[dest] && dist[arc] < minDist) {
							minDist = dist[arc];
							nextNode = dest;
							pred = node;
						}
					}
			}
			visited[nextNode] = true;
			P[nextNode] = pred;
			MSTcost += minDist;
		}
		return MSTcost;
	}

	public static void main(String[] args) {
		// Test graph. See H&S p 237
		int nodes = 7;
		int root = 0;
		int[] hh = { 0, 2, 5, 7, 10, 13, 15, 18 };
		int[] tt = { 1, 5, 0, 2, 6, 1, 3, 2, 4, 6, 3, 5, 6, 4, 0, 1, 3, 4 };
		int[] dd = { 28, 10, 28, 16, 14, 16, 12, 12, 22, 18, 22, 25, 24, 25, 10, 14, 18, 24 };
		Prim p = new Prim(nodes, hh, tt, dd);
		p.prim(root);
		p.print();
	}
}