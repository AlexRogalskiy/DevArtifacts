package src.greedy;
import src.dataStructures.Heap;
import src.dataStructures.Set;

public class Kruskal {		// Assumes connected graph; not checked
	private int nodes;		// Assumes consecutive node numbers
	private int arcs;
	private MSTArc[] inMST; // Arcs in MST
	private int MSTcost;
	private Heap g;
	private Set s;

	Kruskal(int n, int a, MSTArc[] arcList) {
		nodes = n;
		arcs = a;
		inMST= new MSTArc[nodes];
		s= new Set(nodes);
		g= new Heap(arcList);
	}

	public void print() {
		System.out.println("Arcs in MST");
		for (int i = 0; i < nodes-1; i++) {
			System.out.println(inMST[i]);
		}
		System.out.println("MST cost: " + MSTcost);
	}

	public void kruskal() {
		int i= 0;			// Index in inMST array in which arcs are placed if they are in MST
		for (int arc= 0; arc < arcs; arc++) {
			MSTArc d= (MSTArc) g.delete();
			int j= s.collapsingFind(d.from);
			int k= s.collapsingFind(d.to);
			if (j != k) {
				inMST[i++]= d;	
				MSTcost += d.dist;
				s.weightedUnion(j, k);
			}
			if (i == nodes - 1)
				break;
		}
	}

	public static void main(String[] args) {
		// Test graph. See H&S p 237. Node numbers 0 thru 6 rather than 1 thru 7
		int nodes = 7;
		int arcs = 9;
		MSTArc[] arcList= new MSTArc[arcs]; 
		arcList[0]= new MSTArc(0, 1, 28);
		arcList[1]= new MSTArc(0, 5, 10);
		arcList[2]= new MSTArc(1, 2, 16);
		arcList[3]= new MSTArc(2, 3, 12);
		arcList[4]= new MSTArc(3, 4, 22);
		arcList[5]= new MSTArc(4, 5, 25);
		arcList[6]= new MSTArc(1, 6, 14);
		arcList[7]= new MSTArc(3, 6, 18);
		arcList[8]= new MSTArc(4, 6, 24);
		Kruskal k = new Kruskal(nodes, arcs, arcList);
		k.kruskal();
		k.print();
	}
}