package src.greedy;
import src.dataStructures.Heap;

public class PrimHeap {			// Assumes connected graph; not checked
	private int nodes;			// Assumes consecutive node numbers
	private int arcs;
	private int[] head;
	private int[] to;
	private int[] dist;
	private boolean[] visited; 	// Has node been visited in Prim
	private int MSTcost;
	private Heap g;
	private MSTArc[] inMST; 	// Arcs in MST

	PrimHeap(int n, int a,int[] h, int[] t, int[] d) {
		nodes = n;
		arcs= a;
		head = h;
		to = t;
		dist = d;
		g= new Heap(arcs);
		inMST= new MSTArc[nodes];

	}

	public void print() {
		System.out.println("Arcs in MST");
		for (int i = 0; i < nodes-1; i++) {
			System.out.println(inMST[i]);
		}
		System.out.println("MST cost: " + MSTcost);
	}

	public int prim(int root) {
		visited = new boolean[nodes]; 		// Has node been visited in algorithm
		MSTArc inArc= null;
		int k= 0;
		visited[root] = true;				// Initialize root node
		for (int arc= head[root]; arc< head[root+1]; arc++)
			g.insert(new MSTArc(root, to[arc], dist[arc]));

		for (int i = 0; i < nodes-1; i++) {	// Add nodes-1 arcs
			do {	// Find shortest arc to node not yet visited
				inArc= (MSTArc) g.delete();
			} while (visited[inArc.to]);
			inMST[k++]= inArc;		// Could also save predecessor array in prim
			int inNode= inArc.to;
			visited[inNode] = true;
			MSTcost += inArc.dist;
			for (int arc= head[inNode]; arc< head[inNode+1]; arc++)
				g.insert(new MSTArc(inNode, to[arc], dist[arc]));
		}
		return MSTcost;
	}

	public static void main(String[] args) {
		// Test graph. See H&S p 237
		int nodes = 7;
		int arcs= 18;
		int root= 0;
		int[] hh = { 0, 2, 5, 7, 10, 13, 15, 18 };
		int[] tt = { 1, 5, 0, 2, 6, 1, 3, 2, 4, 6, 3, 5, 6, 4, 0, 1, 3, 4 };
		int[] dd = { 28, 10, 28, 16, 14, 16, 12, 12, 22, 18, 22, 25, 24, 25, 10, 14, 18, 24 };
		PrimHeap p = new PrimHeap(nodes, arcs, hh, tt, dd);
		p.prim(root);
		p.print();
	}
}