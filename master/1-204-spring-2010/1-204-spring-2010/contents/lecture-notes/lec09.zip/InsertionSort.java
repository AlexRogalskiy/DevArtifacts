package src.searchSort;

public class InsertionSort {

	public static void sort(Comparable<Object>[] d) {
		sort(d, 0, d.length - 1);
	}

	public static void sort(Comparable<Object>[] d, int start, int end) {
		Comparable<Object> key;
		int i, j;
		for (j = start + 1; j <= end; j++) {
			key = d[j];
			for (i = j - 1; i >= 0 && key.compareTo(d[i]) < 0; i--)
				d[i + 1] = d[i];
			d[i + 1] = key;
		}
	}
}