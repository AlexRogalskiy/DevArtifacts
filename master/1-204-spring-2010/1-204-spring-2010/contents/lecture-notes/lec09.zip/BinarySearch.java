package src.searchSort;
import java.util.*;

public class BinarySearch {
	public static int binSearch(int a[], int x) {
		int low = 0, high = a.length - 1;
		while (low <= high) {
			int mid = (low + high) / 2;		// Not exact middle, but simple
			if (x < a[mid])
				high = mid - 1;
			else if (x > a[mid])
				low = mid + 1;
			else
				return mid;
		}
		return Integer.MIN_VALUE;
	}

	public static void main(String[] args) {
		int[] a= {-1, -3, -5, -7, -9, 2, 6, 9, 3, 4, 98, 309, -55};
		Arrays.sort(a);
		for (int i : a)
			System.out.print(" " + i);
		System.out.println();
		System.out.println("BinSrch location of -1 is " + binSearch(a, -1));
		System.out.println("BinSrch location of -55 is " + binSearch(a, -55));
		System.out.println("BinSrch location of 98 is " + binSearch(a, 98));
		System.out.println("BinSrch location of -7 is " + binSearch(a, -7));
		System.out.println("BinSrch location of  8 is " + binSearch(a, 8));
	}
}