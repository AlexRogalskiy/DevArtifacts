package src.searchSort;
import java.util.*;
import javax.swing.*;

import src.dataStructures.Stack;

public class QuicksortTest {
	private static Random generator= new Random();
	
    public static void main(String[] args) {
    	// Test standard quicksort on random input
        String input= JOptionPane.showInputDialog("Enter no of elements to sort:");
        int size= Integer.parseInt(input);
        System.out.println("Size: "+ size);
        
        Integer[] sortdata= new Integer[size];
        for (int i=0; i < size; i++)
            sortdata[i]= new Integer( (int)(1000*Math.random())); 
        System.out.println("Start regular quicksort, random input");
        long h = System.nanoTime();
        sort(sortdata, 0, size-1);
        long h1 = System.nanoTime();
        System.out.println("Done, time (ms): "+ (h1-h)/1000000);
        if (size <= 1000)
        	for (int i=0; i < size; i++)
            	System.out.println(sortdata[i]);
        
        // Test iterative quicksort on random input
        for (int i=0; i < size; i++)
            sortdata[i]= new Integer( (int)(1000*Math.random())); 
        System.out.println("Start iterative quicksort, random input");
        h = System.nanoTime();
        isort(sortdata, 0, size-1);
        h1 = System.nanoTime();
        System.out.println("Done, time (ms): "+ (h1-h)/1000000);
        if (size <= 1000)
        	for (int i=0; i < size; i++)
            	System.out.println(sortdata[i]);
        
        // Test quicksort with insertionsort for small subfiles on random input
        for (int i=0; i < size; i++)
            sortdata[i]= new Integer( (int)(1000*Math.random())); 
        System.out.println("Start quicksort with insertionsort, random input");
        h = System.nanoTime();
        xsort(sortdata, 0, size-1);
        h1 = System.nanoTime();
        System.out.println("Done, time (ms): "+ (h1-h)/1000000);
        if (size <= 1000)
        	for (int i=0; i < size; i++)
            	System.out.println(sortdata[i]);
        
        // Test random quicksort on already sorted input
        Integer[] alreadysortdata= new Integer[size];
        for (int i=0; i < size; i++)
            alreadysortdata[i]= new Integer(i); 

        System.out.println("Start random quicksort, already sorted input");
        h = System.nanoTime();
        rsort(alreadysortdata, 0, size-1);
        h1 = System.nanoTime();
        System.out.println("Done random, time (ms): "+ (h1-h)/1000000);
        
        // Test Java built-in sort, random input
        for (int i=0; i < size; i++)
            sortdata[i]= new Integer( (int)(1000*Math.random())); 
        System.out.println("Start Java Arrays.sort(), random input");
        h = System.nanoTime();
        Arrays.sort(sortdata);
        h1 = System.nanoTime();
        System.out.println("Done, time (ms): "+ (h1-h)/1000000);
        
        // Test Java built-in sort, already sorted input
        System.out.println("Start Java Arrays.sort(), already sorted input");
        h = System.nanoTime();
        Arrays.sort(alreadysortdata);
        h1 = System.nanoTime();
        System.out.println("Done, time (ms): "+ (h1-h)/1000000);
        
        // Test median of 9 sort with insertion sort, already sorted input
        System.out.println("Start median quicksort, already sorted input");
        h = System.nanoTime();
        msort(alreadysortdata, 0, size-1);
        h1 = System.nanoTime();
        System.out.println("Done, time (ms): "+ (h1-h)/1000000);
        
        /*
        // Test regular quicksort on already sorted input
        // Exhausts stack space (default VM memory) with n= 7000
        System.out.println("Start regular quicksort, already sorted input");
        h = System.nanoTime();
        sort(rsortdata, 0, size-1);
        h1 = System.nanoTime();
        System.out.println("Done, time (ms): "+ (h1-h)/1000000);
        */
        System.exit(0);
    }        
	@SuppressWarnings("unchecked")
    public static void exchange(Comparable[] a, int i, int j) {
        Comparable o= a[i];                 //  Swaps a[i] and a[j]
        a[i]= a[j];
        a[j]= o;
    }
	@SuppressWarnings("unchecked")
    public static int partition(Comparable[] d, int start, int end) {
		Comparable pivot= d[end];           // Partition element
        int low= start -1;
        int high= end;
        while (true) {
            while (d[++low].compareTo(pivot) < 0);  // Move index to right
            while (d[--high].compareTo(pivot) > 0 && high > low);  // Move index to left
            if (low >= high) break;         // Indexes cross
            exchange(d, low, high);         // Exchange elements
        }
        exchange(d, low, end);              // Exchange pivot, right
        return low;
    }
	// Standard quicksort
	@SuppressWarnings("unchecked")
    public static void sort(Comparable[] d, int start, int end) {
        if (start < end) { 
        	int p= partition(d, start, end);
        	sort(d, start, p-1);
        	sort(d, p+1, end);
        }
    }
	// Randomized quicksort
	@SuppressWarnings("unchecked")
    public static void rsort(Comparable[] d, int start, int end) {
		int random = Math.abs(generator.nextInt());
        if (start < end) { 
        	if (end - start > 5)
        		exchange(d, random % (end - start + 1) + start, end);
        	int p= partition(d, start, end);
        	rsort(d, start, p-1);
        	rsort(d, p+1, end);
        }
    }
	// Iterative quicksort.
	@SuppressWarnings("unchecked")
	public static void isort(Comparable[] d, int start, int end) {
		Stack s= new Stack(d.length/10);
		do {
			while (start < end) {
				int p= partition(d, start, end);
				if ((p - start) < (end - p)) {
					s.push(p+1);
					s.push(end);
					end= p-1;
				} else {
					s.push(start);
					s.push(p-1);
					start= p+1;
				}
			}
			if (s.isEmpty())
				return;
			end= (Integer) s.pop();
			start= (Integer) s.pop();
		} while (true);
    }
	// Quicksort with insertion sort on small partitions
	@SuppressWarnings("unchecked")
    public static void xsort(Comparable[] d, int start, int end) {
        if (start < end) { 
        	if (end - start < 10)
        		InsertionSort.sort(d, start, end);
        	else {
        		int p= partition(d, start, end);
        		xsort(d, start, p-1);
        		xsort(d, p+1, end);
        	}
        }
    }
	// Quicksort with median of 9 and insertion sort on small partitions
	@SuppressWarnings("unchecked")
	public static int med3(Comparable[] x, int a, int b, int c) {
		return (x[a].compareTo(x[b])<0 ?
				(x[b].compareTo(x[c])<0 ? b : x[a].compareTo(x[c]) <0? c : a) :
				(x[b].compareTo(x[c])>0 ? b : x[a].compareTo(x[c]) >0? c : a));
	}
	
	@SuppressWarnings("unchecked")
	public static void msort(Comparable[] d, int start, int end) {
        if (start < end) { 
        	if (end - start < 10)
        		InsertionSort.sort(d, start, end);
        	else {
        		int l= start;
        		int n= end;
        		int m= (end - start)/2;
        		if (end - start > 40) {
        			int s= (end - start)/8;
        			l= med3(d, l, l+s, l+2*s);
        			m= med3(d, m-s, m, m+s);
        			n= med3(d, n-2*s, n-s, n);
        			m= med3(d, l, m, n);
        		}
        		exchange(d, m, end);
        		int p= partition(d, start, end);
        		msort(d, start, p-1);
        		msort(d, p+1, end);
        	}
        }
    }
}