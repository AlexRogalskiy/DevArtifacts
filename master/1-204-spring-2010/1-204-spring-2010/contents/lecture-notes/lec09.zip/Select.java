package src.searchSort;

public class Select {
	@SuppressWarnings("unchecked")
	public static void select1(Comparable[] a, int k) {
		int low = 0, up = a.length-1; 
		do {
			int j = QuicksortTest.partition(a, low, up);
			if (k == j)
				return;
			else if (k < j)
				up = j-1; 
			else
				low = j+1;
		} while (true);
	}

	public static void main(String[] args) {
		
		Integer[] a= {65, 70, 75, 80, 85, 60, 55, 50, 45, 99};
		select1(a, 0);
		for (int element : a)
			System.out.print(element + " ");
		System.out.println("\n0th element is: "+ a[0]);
		System.out.println();
		
		Integer[] b= {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,0};
		select1(b, 5);
		for (int element : b)
			System.out.print(element + " ");
		System.out.println("\n5th element is: "+ b[5]);
		System.out.println();
		
		Integer[] c= {15,14,13,12,11,10,9,8,7,6,5,4,3,2,1,15};
		select1(c, 6);
		for (int element : c)
			System.out.print(element + " ");
		System.out.println("\n6th element is: "+ c[6]);
		System.out.println();
		
		Integer[] e= {3,7,2,0,-1,8,1,9,6,4,5,55,54};
		select1(e, 6);
		for (int element : e)
			System.out.print(element + " ");
		System.out.println("\n6th element is: "+ e[6]);
		System.out.println();
		
		Integer[] d= {65, 70, 75, 80, 85, 60, 55, 50, 45, -1};
		select1(d, 7);
		for (int element : d)
			System.out.print(element + " ");
		System.out.println("\n7th element is: "+ d[7]);
		System.out.println();
	}
}