package src.greedy;
import java.util.Arrays;

import src.dataStructures.Set;

public class JobSeqFast {
	private static class Item implements Comparable<Object> {
		private int profit;
		private int deadline;
		private String name;

		public Item(int p, int d, String n) {
			profit= p;
			deadline= d;
			name= n;
		}

		public int compareTo(Object o) {
			Item other = (Item) o;
			if (profit > other.profit)		// Descending sort
				return -1;
			else if (profit < other.profit)
				return 1;
			else
				return 0;
		}
	}
	
	public static int[] fjs(Item[] jobs, int b) {		// Returns array j with indices of optimal jobs to be done
		int n= jobs.length;
		int[] j= new int[n];
		Set jobSet = new Set(b);
		int[] f = new int[b];				// index of highest free time slot for job due at time i
		for (int i = 0; i < b; i++)
			f[i] = i;
		for (int i = 1; i < n; i++) {		// Try to include highest profit jobs in order
			int q = jobSet.collapsingFind(Math.min(n, jobs[i].deadline));				// Find root of tree associated with job i
			if (f[q] != 0) {				// If slot available within deadline of job i
				j[q] = i;					// Add job i to optimal set, in its (latest) time slot
				int m = jobSet.collapsingFind(f[q] - 1);		// Find root of tree with next highest (but lower) time slot
				jobSet.weightedUnion(m, q);	// Combine the two sets now that current job has taken a slot
				f[q] = f[m]; 				// If q is new root, update its f value (highest free slot). If m is root, this operation is redundant
			}
		}
		return j;						// Jobs in optimal set
	}
	
	public static int[] simpleJobSched(Item[] jobs) {
		int n= jobs.length;
		int[] jobSet= new int[n];			// jobSet is return value; it contains indices of optimal jobs to be done
		boolean[] slot= new boolean[n];		// slot is initially false (not taken). Updated to true when job scheduled in it
		for (int i= 1; i < n; i++) {
			for (int j= jobs[i].deadline; j > 0; j--) {
				if (!slot[j]) {
					slot[j]= true;
					jobSet[j]= i;
					break;
				}
			}
		}
		return jobSet;
	}

	public static void main(String args[]) {
		Item sentinel= new Item(0, 0, "sentinel");
		Item a = new Item(100, 2, "a");
		Item b = new Item(19, 1, "b");
		Item c = new Item(27, 2, "c");
		Item d = new Item(25, 1, "d");
		Item e = new Item(15, 3, "e");
		
		Item[] jobs = { sentinel, a, b, c, d, e };
		Arrays.sort(jobs, 1, jobs.length-1);	// Sort in descending order, skip sentinel
		
		int maxD= -1;			// Maximum deadline
		for (Item i: jobs)
			if (i.deadline > maxD)
				maxD= i.deadline;
		maxD++;					// Determines no of slots; if max d is x, need x+1 slots (0 thru x)
		
		int bb= Math.min(maxD, jobs.length);
		int[] j= fjs(jobs, bb);
		int numJobs= 0;
		int totalProfit= 0;
		System.out.println("Jobs done:");
		for (int i= 1; i < maxD; i++) {
			if (j[i]>0) {
				System.out.println(" Job "+ jobs[j[i]].name+ " at time "+ i);
				numJobs++;
				totalProfit += jobs[j[i]].profit;
			}
		}
		System.out.println("Number of jobs done: " + numJobs + ", total profit: " + totalProfit);
		
		// Test simple version of job scheduling
		int[] jSimple= simpleJobSched(jobs);
		numJobs= 0;
		totalProfit= 0;
		System.out.println("\nJobs done:");
		for (int i= 1; i < maxD; i++) {
			if (jSimple[i]>0) {
				System.out.println(" Job "+ jobs[jSimple[i]].name+ " at time "+ i);
				numJobs++;
				totalProfit += jobs[jSimple[i]].profit;
			}
		}
		System.out.println("Number of jobs done: " + numJobs + ", total profit: " + totalProfit);
	}
}