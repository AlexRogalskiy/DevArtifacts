package src.greedy;
import java.util.*;
public class Knapsack {
	public static final double TOLERANCE= 1E-15;

	private static class Item implements Comparable<Object> {
		public double ratio;
		public int weight;

		public Item(double r, int w) {
			ratio = r;
			weight = w;
		}

		public int compareTo(Object o) {
			Item other = (Item) o;
			if (ratio > other.ratio)		// Descending sort
				return -1;
			else if (ratio < other.ratio)
				return 1;
			else
				return 0;
		}
	}
	public static double[] knapsack(Item[] e, int m) {
		int upper = m;		// Knapsack capacity
		// 0-1 answer array: 1 if item in knapsack, 0 if not
		double[] x= new double[e.length];
		int i;
		for (i= 0; i < e.length; i++) {
			if (e[i].weight  > upper )
				break;
			x[i]= 1.0;
			upper -= e[i].weight;
		}
		if (i < e.length)		// If all items not in knapsack
			x[i]= (double) upper/ e[i].weight;
		return x;
	}

	public static void main(String[] args) {
		Item a = new Item(2.0, 2);
		Item b = new Item(1.5, 4);
		Item c = new Item(2.5, 2);
		Item d = new Item(1.66667, 3);
		Item[] e = { a, b, c, d };
		Arrays.sort(e);
		int m = 7;
		System.out.println("Capacity: " + m);
		double[] projectSet= knapsack(e, m);
		double cumProfit= 0.0;
		for (int i= 0; i < e.length; i++) {
			System.out.println("i: "+ " ratio: " + e[i].ratio +"\t wgt: " + e[i].weight + 
				"\t profit: " + e[i].weight*e[i].ratio +"\t in? " + projectSet[i]);
			cumProfit+= projectSet[i]*e[i].weight*e[i].ratio;
		}
		System.out.println("Cumulative benefit: " + cumProfit);
	}
}