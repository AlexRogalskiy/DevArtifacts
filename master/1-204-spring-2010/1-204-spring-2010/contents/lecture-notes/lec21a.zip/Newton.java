package src.newton;

import src.linear.Gauss;

public class Newton {
	public static double[] mnewt(int nTrial, double[] x, MathFunction2 func) {
		final double TOLERANCE= 1E-13;
		int n= x.length;
		double[] p= new double[n];
		double[] fvec= new double[n];
		double[][] fjac= new double[n][n];
		for (int k= 0; k < nTrial; k++) {
			fvec= func.func(x);
			fjac= func.jacobian(x);
			double errf= 0.0;
			for (int i= 0; i < n; i++)
				errf += Math.abs(fvec[i]);
			if (errf < TOLERANCE)
				return x;
			for (int i= 0; i < n; i++) 
				p[i]= -fvec[i];
			p= Gauss.gaussian(fjac, p);
			double errx= 0.0;
			for (int i= 0; i < n; i++) {
				errx += Math.abs(p[i]);
				x[i] += p[i];
			}
			if (errx <= TOLERANCE)
				return x;
		}
		return x;
	}
}