package src.newton;

public class SimpleModelTest {
	public static void main(String[] args) {
		SimpleModel s= new SimpleModel();
		int nTrial= 20;
		double[] x= {1.5, 3.5};		// Initial guess
		x= Newton.mnewt(nTrial, x, s);
		for (double d : x)
			System.out.println(d);
	}
}