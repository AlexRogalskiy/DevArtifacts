package src.newton;

public interface MathFunction2 {
	double[] func(double[] x);
	double[][] jacobian(double[] x);
}
