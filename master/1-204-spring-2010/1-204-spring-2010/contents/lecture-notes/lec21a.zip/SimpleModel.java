package src.newton;

public class SimpleModel implements MathFunction2 {
	@Override
	public double[] func(double[] x) {
		double[] f= new double[x.length];
		f[0]= x[0]*x[0] + x[0]*x[1] - 10;
		f[1]= x[1] + 3*x[0]*x[1]*x[1] - 57;
		return f;
	}
	@Override
	public double[][] jacobian(double[] x) {
		int n= x.length;
		double[][] j= new double[n][n];
		j[0][0]= 2*x[0] + x[1];
		j[0][1]= x[0];
		j[1][0]= 3*x[1]*x[1];
		j[1][1]= 1 + 6*x[0]*x[1];
		return j;
	}
}