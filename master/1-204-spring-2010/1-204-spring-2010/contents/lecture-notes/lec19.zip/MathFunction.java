package src.network;

public interface MathFunction {
	double derivative(double alpha);
}