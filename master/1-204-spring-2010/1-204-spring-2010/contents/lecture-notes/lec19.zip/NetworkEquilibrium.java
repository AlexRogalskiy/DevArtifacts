package src.network;

// This code is tested only on the small example from Sheffi, p. 120
// Will be more fully tested for next year...

public class NetworkEquilibrium implements MathFunction {
    public static final int EMPTY= Short.MIN_VALUE;           // Flag for no value: -32767
    private int nodes;
    private int arcs;
    private int[] head;
    private int[] to;
    private double[] timeBase;
    private double[] timeExponent;
    private double[] timeConst;
	private double[] D;                 // Distance from root
	private int[] P;                    // Predecessor node back to root
	private int[] Parc;					// Predecessor arc back to root
	private double[] xFlow;				// Arc flows
	private double[] yFlow;				// Auxiliary arc flows
	private double[] arcTime;
	private double[][] ODtrips;
    
    NetworkEquilibrium(int n, int a, int[] h, int[] t, double[] tBase, double[] tExponent, double[] tConst, double[][] od) {
        nodes= n;
        arcs= a;
        head= h;
        to= t;
        timeBase= tBase;
        timeExponent= tExponent;
        timeConst= tConst;
        ODtrips= od;
        arcTime= new double[arcs];
    }
    
    NetworkEquilibrium() {
        // Test graph, Sheffi Fig 5.1
        nodes= 2;
        arcs= 3;
        head= new int[nodes+1];
        to= new int[arcs];
        timeBase= new double[arcs];
        timeExponent= new double[arcs];
        timeConst= new double[arcs];
        head[0]= 0; head[1]= 3; head[2]= 3;
        to[0]= 1;   to[1]= 1;   to[2]= 1;
        timeBase[0]= 10; timeBase[1]= 20; timeBase[2]= 25;		// In minutes
        timeExponent[0]= 4; timeExponent[1]= 4; timeExponent[2]= 4;
        timeConst[0]= 0.15/2/2/2/2; timeConst[1]= 0.15/4/4/4/4; timeConst[2]= 0.15/3/3/3/3;
        ODtrips= new double[nodes][nodes];
        ODtrips[0][1]= 10.0;		// All other flows = 0.0
        arcTime= new double[arcs];
    }
    
    // Modifications:
    // 1. Time is method, not data from array. (Replace 'dist' with 'time' from original version)
    // 2. Times are doubles, not ints
    // 3. Must keep track of predecessor arc as well as predecessor node, since there may be multiple arcs
    // 4. Method is private
    
    private void shortHKNetwork(int root) {
        final int MAX_COST= Integer.MAX_VALUE/2;    // 'Infinite' initial value
        final int NEVER_ON_CL= -1;                  // Node never on CL before
        final int ON_CL_BEFORE= -2;                 // Node on CL before
        final int END_OF_CL= Integer.MAX_VALUE;     // Sentinel for end of CL; larger than max node number
        
        D= new double[nodes];                    	// Distance from root
        P= new int[nodes];                    		// Predecessor node from root
        Parc= new int[nodes];						// Predecessor arc from root
        int[] CL= new int[nodes];                   // Candidate list position
        
        for (int i=0; i < nodes; i++) {             // Initialize all nodes
            D[i]= MAX_COST;                         // Initial label-> infinity
            P[i]= EMPTY;                            // No predecessor node on path
            Parc[i]= EMPTY;							// No predecessor arc on path
            CL[i]= NEVER_ON_CL;                     // Never on candidate list
        }
        
        // Initialize root node
        D[root]= 0;                                 // Root is 0 distance from root
        CL[root]=  END_OF_CL;                       // Put root at end of CL
        int lastOnList= root;
        int firstNode= root;
        
        do {
            double Dfirst= D[firstNode];                   // Shortcut for D[firstNode]
            // Check through all links out of "node"
            for (int link= head[firstNode]; link < head[firstNode+1]; link++) {
                int outNode= to[link];
                double DoutNode= Dfirst+ time(link); 	// Dist to node via first node in CL
                if (DoutNode < D[outNode]) {            // If this is an improvement
                    P[outNode]= firstNode;              // Record new predecessor node
                    Parc[outNode]= link;				// Record new predecessor arc
                    D[outNode]= DoutNode;               // Update for shorter distance
                    int CLoutNode= CL[outNode];         // Add node to CL
                    // Only differences are in next if-else
                    if (CLoutNode == NEVER_ON_CL || CLoutNode == ON_CL_BEFORE) {     // See if node has been on CL before
                        int CLfirstNode= CL[firstNode];
                        if (CLfirstNode != END_OF_CL &&
                        (CLoutNode == ON_CL_BEFORE || DoutNode < D[CLfirstNode])){   // Add to front
                            CL[outNode]= CLfirstNode;
                            CL[firstNode]= outNode;
                        }
                        else {                          // Add to rear of CL
                            CL[lastOnList]= outNode;        // If node has never been on CL, add it to the end
                            lastOnList= outNode;
                            CL[outNode]= END_OF_CL;
                        }
                    }
                }
            }
            int nextCL= CL[firstNode];
            CL[firstNode]= ON_CL_BEFORE;
            firstNode= nextCL;
        } while (firstNode < END_OF_CL);
    }
    
    private double time(int link) {
    	final double TOLERANCE= 1E-8;		// Square root of machine precision
    	double time;
    	if (xFlow[link] < TOLERANCE)
    		time= timeBase[link];
    	else {
    		double delay= 1.0 + timeConst[link]*Math.pow(xFlow[link], timeExponent[link]);
    		time= timeBase[link]*delay;
    	}
    	return time;
    }
    
    private void update() {
    	for (int i= 0; i < arcs; i++) {
    		arcTime[i]= time(i);
    	}
    }
    
    private double[] directionFind() {
    	double[] flow= new double[arcs];
    	// Assign trips on shortest path (set of arcs)
    	for (int i= 0; i < nodes; i++) {  	// Loop thru all origin nodes
    		shortHKNetwork(i);				// Find shortest path from origin i to all nodes
    		for (int j= 0; j < nodes; j++) {
    			if (i != j) {
    				int pred= P[j];
    				while (pred != EMPTY) {	// While not back at root
    					flow[Parc[j]] += ODtrips[i][j];	// Add this OD flow to arcs in shortest path from O to D
    					pred= P[pred];					// Find previous arc on path, until we reach the root
    				}	
    			}
    		}
    	}
    	return flow;
    	// We now have flows on all arcs, based on initial travel times	
    }
    
    public double derivative(double alpha) {
	   	final double TOLERANCE= 1E-8;		// Square root of machine precision
    	double deriv= 0.0;
    	for (int i= 0; i < arcs; i++) {
        	double time;
        	double newFlow= xFlow[i]+ alpha*(yFlow[i]- xFlow[i]);
        	if (newFlow < TOLERANCE)
        		time= timeBase[i];
        	else {
        		double delay= 1.0 + timeConst[i]*Math.pow( newFlow, timeExponent[i]);
        		time= timeBase[i]*delay;
        	}
    		deriv += (yFlow[i] - xFlow[i])*time;
    	}
    	return deriv;
    }
    
    private double lineSearch(MathFunction d, double a, double b) {
    	final double TOLERANCE= 1E-8;		// Square root of machine precision
    	final double MAX_ITERATIONS= 1000;
        double m;							// Midpoint
        int counter= 0;
        for (m= (a+b)/2.0; Math.abs(a-b) > TOLERANCE; m= (a+b)/2.0) {
        	counter++;
            if  (d.derivative(m)< 0.0)    // If derivative negative, 
                a= m;       // Use right subinterval
            else
                b= m;       // Use left subinterval
            if (counter > MAX_ITERATIONS)
            	break;
        }
        return m;
    }
    
    private double move(double alpha) {
    	double sumFlows= 0.0;
    	double sumRootMeanDiffFlows= 0.0;
    	for (int i= 0; i < arcs; i++) {
    		double flowChange= alpha*(yFlow[i] - xFlow[i]);
    		xFlow[i]+= flowChange;
    		sumFlows+= xFlow[i];
    		sumRootMeanDiffFlows+= flowChange*flowChange;
    	}
    	// Compute convergence criterion here, since we have current and previous xFlow
    	return Math.sqrt(sumRootMeanDiffFlows)/sumFlows;
    }
    
    public void equilibrium() {
    	final double CRITERION= 0.001;		// Convergence criterion: 1% change in flows (root mean square)
    	final int MAX_ITERATIONS= 10;		// Should be set higher in real code
        // Step 0: Initialization. Find times at zero flow, then assign flow based on times
    	xFlow= new double[arcs];			// Initialize xFlow = 0 (clumsy?)
    	update();
    	printTime();
    	xFlow= directionFind();
    	printMove();
    	
        double convergence;
        int iterations= 0;
        do {
        	// Step 1: Set times based on initial flows
            update();
            printTime();				// For Sheffi output
        	// Step 2: Direction finding. All or nothing assignment based on updated times
        	yFlow= directionFind();
        	// Step 3: Line search.
        	double alpha= lineSearch(this, 0.0, 1.0);	// Alpha between 0 and 1
        	printDirection(alpha);
        	// Step 4: Move
        	convergence= move(alpha);
        	printMove();
        	// Step 5: Check convergence
        	iterations++;
        } while (convergence > CRITERION && iterations < MAX_ITERATIONS);
    }

    private void printDirection(double a) {
    	System.out.print("Direction  y: \t");
       	for (int i= 0; i < arcs; i++)
    		System.out.printf("%5.2f ",yFlow[i]);
       	System.out.printf("               %5.3f", a);
    	System.out.println();	
    }  
    
    private void printMove() {
    	System.out.print("Move       x: \t");
       	for (int i= 0; i < arcs; i++)
    		System.out.printf("%5.2f ",xFlow[i]);
    	System.out.println("\n");	
    }  
    
    private void printTime() {
    	System.out.print("Update     t: \t");
       	for (int i= 0; i < arcs; i++)
    		System.out.printf("%5.1f ",arcTime[i]);
       	// Compute and output objective function value
       	// Integral of a+bx^4 is ax+bx^5/5
       	// Integral has no economic or physical meaning in this problem
       	double obj= 0.0;
       	for (int i= 0; i < arcs; i++) {
       		double x5= xFlow[i]*xFlow[i]*xFlow[i]*xFlow[i]*xFlow[i]/5.0;
       		obj += timeBase[i]*xFlow[i] + timeBase[i]*timeConst[i]*x5;
       	}
       	System.out.printf("%8.2f ",obj);
    	System.out.println();	
    }
    
    public static void main(String[] args) {
        NetworkEquilibrium g= new NetworkEquilibrium();
        g.equilibrium();
    }   
}