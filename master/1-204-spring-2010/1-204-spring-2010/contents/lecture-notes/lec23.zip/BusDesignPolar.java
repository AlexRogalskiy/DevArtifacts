package src.analytical;

// This is a very simplified version.

public class BusDesignPolar {
    private static final double a1= 0.42;  	// Demand coefficients: constant
    private static final double a2= -0.0081;	// Wait and walk time
    private static final double a3= -0.0066;	// In vehicle travel time
    private static final double a4= -0.0010;	// Fare
    private static final double a5= 0.0292;		// Auto time and cost
    private static final double b= 0.2;		// Bus stop spacing (mi)
    private static final double c= 62;    	// Bus operating cost (cents/min)
    private static final double j= 0.043;	// Avg walk speed (mi/min)
    private static final double k= 0.4;    	// Wait-hdwy ratio
    private static final double m4= 1.0;    // Peak direction ratio
    private static final double p0= 12.0;	// Trip density, all modes, in linearly declining density formulation
    private static final double v= 0.18;  	// Bus speed, local, mi/min
    private static final double T= 60;   	// Time period of analysis (min)
    private static final double Y= 8; 		// Radius of analysis area (mi)
    private static final double W= 2*Math.PI*Y;		// Width (segment) of analysis area (mi)
    private static final double s= 50;		// Vehicle size
    
    // Inputs
    private double y;		// Shadow price of deficit constraint

    // Outputs
    private double f;		// Optimal fare (cents) 
    private double theta;	// Optimal route spacing (radians) 
    private double h;		// Optimal headway (min) 
    private double L;		// Route length
    private double q;		// Transit load factor at peak load point
    private double t;		// Transit mode share
    //private double yc;		// Shadow price of bus capacity constraint. Not computed.
    private double R;		// Revenue
    private double P;		// Passengers
    private double C;		// Operating cost
    private double B;		// Net transit user benefit
    private double A;		// Mode share constant terms; helper value
    private double f1;		// Optimal fare (cents) with vehicle capacity constraint 
    private double theta1;	// Optimal route spacing (radians) with vehicle capacity constraint 
    private double h1;		// Optimal headway (min) with vehicle capacity constraint 
    private double t1;		// Transit mode share with vehicle capacity constraint
    private double R1;		// Revenue with vehicle capacity constraint
    private double P1;		// Passengers with vehicle capacity constraint
    private double C1;		// Operating cost with vehicle capacity constraint
    private double B1;		// Net transit user benefit with vehicle capacity constraint
    private double q1;		// Transit load factor at peak load point with vehicle capacity constraint
    private boolean outputNoVehConstr;
    private boolean outputVehConstr;
    
    public BusDesignPolar(double y, boolean noVeh, boolean veh) {
    	this.y= y;
    	A= a1 + 0.25*a2*b/j + (a3/v + a5)*2*Y/3;
    	outputNoVehConstr= noVeh;
    	outputVehConstr= veh;
    }
  
    public void optimize() {
       	// Set vehicle capacity constrained solution = unconstrained initially
    	// All local service, no express service
    	
    	double la= 4*j*v*p0*A*A*A*A*y;
    	double lb= Math.abs(c*a4*a2*a2*k*(2*y-1));		// Always negative
    	L= Y*(1+ 1/(6- Math.pow(la/lb, 1.0/3.0)));
    	
    	double ha= c*a4*(2*y-1)*3*Y*(4*Y-3*L);
    	double hb= 2*j*k*k*v*p0*a2*A*y*(3*Y-2*L)*(3*Y-2*L);
    	h1= h= Math.pow(ha/hb, 1.0/3.0);
    	
    	double thetaa= 768*c*a4*j*j*k*(2*y-1)*Y*(3*Y-2*L);
    	double thetab= v*p0*a2*A*y*(4*Y-3*L)*(4*Y-3*L);
    	theta1= theta= Math.pow(thetaa/thetab, 1.0/3.0)/L;
    	
    	f1= f= (1-y)/((2*y-1)*a4)*(A+2*a2*k*h);
    	double AA= (4*Y*L-3*L*L)/(6*Y-4*L);
    	t1= t= A + a2*k*h +a4*f + 0.25*a4*theta*AA/j;
    	double LL= 6*Y*s/(p0*a4*m4*(3*Y*L*L-2*L*L*L));
    	q= theta*h/(a4*LL)*(A + a2*k*h + a4*f + 0.25*a4*theta*AA/j);
    	
    	P1= P= W*T*s*t/(Y*a4*m4*LL);
    	R1= R= P*f;
    	C1= C= 2*W*T*L*c/(Y*theta*h*v);
    	B1= B= -W*T*s*t*t/(2*Y*a4*a4*m4*LL);
    	
    	if (q > 1.0) {
    		h1= h/Math.sqrt(q);
    		theta1= theta/Math.sqrt(q);
    		f1= f + a2*k*(h-h1)/a4;
    		t1= A + a2*k*h1 +a4*f1 + 0.25*a4*theta1*AA/j;
    		q1= theta1*h1/(a4*LL)*(A + a2*k*h1 + a4*f1 + 0.25*a4*theta1*AA/j);
    		P1= W*T*s*t1/(Y*a4*m4*LL);
        	R1= P*f1;
        	C1= 2*W*T*L*c/(Y*theta1*h1*v);
        	B1= -W*T*s*t1*t1/(2*Y*a4*a4*m4*LL);
    	}
    	print();
    }
    
    private void print() {
    	if (outputNoVehConstr) {
    	System.out.println("No vehicle capacity constraint");
    	System.out.printf(" Route length: %5.1f%n" , L);
    	System.out.printf(" Route spacing: %5.2f%n" , theta);
    	System.out.printf(" Route headway: %5.1f%n" , h);
    	System.out.printf(" Fare: %5.0f%n" , f);
    	System.out.printf(" Load factor: %5.2f%n" , q);
    	System.out.printf(" Transit mode share: %5.3f%n" , t);
    	System.out.printf(" Deficit shadow price: %5.2f%n" , y);
    	System.out.printf(" Transit revenue: $%5.0f%n" , R/100);
    	System.out.printf(" Transit passengers: %5.0f%n" , P);
    	System.out.printf(" Transit operating cost: $%5.0f%n" , C/100);
    	System.out.printf(" Net transit user benefit: $%5.0f%n" , B/100);
    	System.out.printf(" Passenger load per bus: %5.0f%n" , q*s);
    	System.out.printf(" Value of objective function: $ %5.0f%n" , (B/y + R - C)/100);
    	System.out.printf(" Transit deficit: $%5.0f%n" , (C-R)/100);
    	}
    	if (outputVehConstr) {
    	System.out.println("\nVehicle capacity constraint");
    	System.out.printf(" Route length: %5.1f%n" , L);
    	System.out.printf(" Route spacing: %5.2f%n" , theta1);
    	System.out.printf(" Route headway: %5.1f%n" , h1);
    	System.out.printf(" Fare: %5.0f%n" , f1);
    	System.out.printf(" Load factor: %5.2f%n" , q1);
    	System.out.printf(" Transit mode share: %5.3f%n" , t1);
    	System.out.printf(" Deficit shadow price: %5.2f%n" , y);
    	System.out.printf(" Transit revenue: $ %5.0f%n" , R1/100);
    	System.out.printf(" Transit passengers: %5.0f%n" , P1);
    	System.out.printf(" Transit operating cost: $ %5.0f%n" , C1/100);
    	System.out.printf(" Net transit user benefit: $ %5.0f%n" , B1/100);
    	System.out.printf(" Passenger load per bus: %5.0f%n" , q1*s);
    	System.out.printf(" Value of objective function: $ %5.0f%n" , (B1/y + R1 - C1)/100);
    	System.out.printf(" Transit deficit: $%5.0f%n" , (C1-R1)/100);
    	}
    }
    
    public static void main(String[] args) {
    	// Set y= 1.5 for user benefit/deficit tradeoff in this example
    	System.out.println("Benefit/deficit tradeoff");
    	BusDesignPolar benefitMix= new BusDesignPolar(1.5, true, true);
    	benefitMix.optimize();
    	
    	// Set y= 1000 or higher for profit maximization; y= 1 for net user benefit max; between 1 and 1000 to vary deficit constraint
    	System.out.println("\nProfit maximization");
    	BusDesignPolar profitMax= new BusDesignPolar(1000.0, true, true);
    	profitMax.optimize();
    	
    	// Loop to find breakeven point, in general. This example just outputs the answer with y already set.
    	
    	System.out.println("\nBreakeven deficit constraint, no vehicle size constraint");
    	BusDesignPolar defConstraint= new BusDesignPolar(1.25, true, false);
    	defConstraint.optimize();
    	
    	System.out.println("\nBreakeven deficit constraint, vehicle size constraint");
    	BusDesignPolar defConstraint2= new BusDesignPolar(1.75, false, true);
    	defConstraint2.optimize();
    }
}