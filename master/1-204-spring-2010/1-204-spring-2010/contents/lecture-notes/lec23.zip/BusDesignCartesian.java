package src.analytical;

//This is a very simplified version.

public class BusDesignCartesian {
	private static final double a1= 0.38;  	// Demand coefficients: constant
	private static final double a2= -0.0081;	// Wait and walk time
	private static final double a3= -0.0033;	// In vehicle travel time
	private static final double a4= -0.0014;	// Fare
	private static final double a5= 0.0328;		// Auto time and cost
	private static final double b= 0.2;		// Bus stop spacing (mi)
	private static final double c= 50;    	// Bus operating cost (cents/min)
	private static final double d= 3;		// Avg trip length (mi)
	private static final double j= 0.05;	// Avg walk speed (mi/min)
	private static final double k= 0.4;    	// Wait-hdwy ratio
	private static final double p= 3.59;  	// Trip density, all modes (trips/mi^2/min)
	private static final double v= 0.167;  	// Bus speed, local, mi/min
	private static final double T= 60;   	// Time period of analysis (min)
	private static final double X= 4;		// Width of analysis area (mi)
	private static final double Y= 6; 		// Length of analysis area (mi)
	// Inputs
	private double s;		// Vehicle size
	private double y;		// Shadow price of deficit constraint

	// Outputs
	private double f;		// Optimal fare (cents) 
	private double g;		// Optimal route spacing (mi) 
	private double h;		// Optimal headway (min) 
	private double q;		// Transit load factor at peak load point
	private double t;		// Transit mode share
	private double yc;		// Shadow price of bus capacity constraint
	private double R;		// Revenue
	private double P;		// Passengers
	private double C;		// Operating cost
	private double B;		// Net transit user benefit
	private double A;		// Mode share constant terms; helper value
	private double f1;		// Optimal fare (cents) with vehicle capacity constraint 
	private double g1;		// Optimal route spacing (mi) with vehicle capacity constraint 
	private double h1;		// Optimal headway (min) with vehicle capacity constraint 
	private double t1;		// Transit mode share with vehicle capacity constraint
	private double R1;		// Revenue with vehicle capacity constraint
	private double P1;		// Ridership with vehicle capacity constraint
	private double C1;		// Operating cost with vehicle capacity constraint
	private double B1;		// Net transit user benefit with vehicle capacity constraint
	private double q1;		// Transit load factor at peak load point with vehicle capacity constraint
	private boolean outputNoVehConstr;
	private boolean outputVehConstr;

	public BusDesignCartesian(double y, double s, boolean noVeh, boolean veh) {
		this.y= y;
		this.s= s;
		A= a1 + 0.25*a2*b/j + a3*d/v + a5*d;
		outputNoVehConstr= noVeh;
		outputVehConstr= veh;
	}

	public void optimize() {
		// Set vehicle capacity constrained solution = unconstrained initially
		double n1= 32*j*j*k*a4*c*(2*y-1);
		double n2= v*p*a2*A*y;
		g1= g= Math.pow(n1/n2, 1.0/3.0);

		double n3= a4*c*(2*y-1);
		double n4= 2*j*k*k*v*p*a2*A*y;
		h1= h= Math.pow(n3/n4, 1.0/3.0);

		double n5= (1-y)/(2*y-1);
		double n6= A/a4 + Math.pow((4*k*c*a2*a2*(2*y-1))/(v*p*j*a4*a4*A*y), 1.0/3.0);
		f1= f= n5 * n6;

		t1= t= A + a2*(k*h + 0.25*g/j) + a4*f;
		yc= 0.0;
		q= g*h*p*Y*t/s;

		P1= P= T*p*X*Y*t;
		R1= R= P*f;
		C1= C= 2*X*Y*T*c/(g*h*v);
		B1= B= -0.5*T*p*X*Y*t*t/a4;

		if (q > 1.0) {
			g1= Math.sqrt(4*j*k*s*s*v*(2*y-1)/(p*Y*y*(c*2*Y*a4+ A*v*s)));
			h1= Math.sqrt(v*s*s*(2*y-1)/(4*j*k*p*Y*y*(2*c*Y*a4 + A*v*s)));
			f1= (1-y)/(2*y-1)*A/a4 + 2*c*Y*y/(v*s*(2*y-1)) - (a2/(2*j*a4))*Math.sqrt(4*j*k*v*s*s*((2*y-1))/(p*Y*y*(2*c*Y*a4 + A*v*s)));
			t1= A + a2*(k*h1 + 0.25*g1/j) + a4*f1;
			q1= g1*h1*p*Y*t1/s;
			yc= T*X*p*Y*y*(2*c*Y*a4 + A*v*s)/(v*s*s*(2*y-1))*(2*c*Y/(v*s) - (a2/(2*j*a4)*Math.sqrt(4*j*k*v*s*s*(2*y-1)/(p*Y*y*(2*c*Y*a4+ A*v*s)))));
			P1= T*p*X*Y*t1;
			R1= P1*f1;
			C1= 2*X*Y*T*c/(g1*h1*v);
			B1= -0.5*T*p*X*Y*t1*t1/a4;
		}
		print();
	}

	private void print() {
		if (outputNoVehConstr) {
			System.out.println("No vehicle capacity constraint");
			System.out.printf(" Route length: %5.1f%n" , Y);
			System.out.printf(" Route spacing: %5.2f%n" , g);
			System.out.printf(" Route headway: %5.1f%n" , h);
			System.out.printf(" Fare: %5.0f%n" , f);
			System.out.printf(" Load factor: %5.2f%n" , q);
			System.out.printf(" Transit mode share: %5.3f%n" , t);
			System.out.printf(" Deficit shadow price: %5.2f%n" , y);
			System.out.println(" Bus capacity shadow price: 0");
			System.out.printf(" Transit revenue: $%5.0f%n" , R/100);
			System.out.printf(" Transit passengers: %5.0f%n" , P);
			System.out.printf(" Transit operating cost: $%5.0f%n" , C/100);
			System.out.printf(" Net transit user benefit: $%5.0f%n" , B/100);
			System.out.printf(" Passenger load per bus: %5.0f%n" , q*s);
			System.out.printf(" Value of objective function: $ %5.0f%n" , (B/y + R - C)/100);
			System.out.printf(" Transit deficit: $%5.0f%n" , (C-R)/100);
		}
		if (outputVehConstr) {
			System.out.println("\nVehicle capacity constraint");
			System.out.printf(" Route length: %5.1f%n" , Y);
			System.out.printf(" Route spacing: %5.2f%n" , g1);
			System.out.printf(" Route headway: %5.1f%n" , h1);
			System.out.printf(" Fare: %5.0f%n" , f1);
			System.out.printf(" Load factor: %5.2f%n" , q1);
			System.out.printf(" Transit mode share: %5.3f%n" , t1);
			System.out.printf(" Deficit shadow price: %5.2f%n" , y);
			System.out.printf(" Bus capacity shadow price: $%5.2f%n" , yc/100);
			System.out.printf(" Transit revenue: $ %5.0f%n" , R1/100);
			System.out.printf(" Transit passengers: %5.0f%n" , P1);
			System.out.printf(" Transit operating cost: $ %5.0f%n" , C1/100);
			System.out.printf(" Net transit user benefit: $ %5.0f%n" , B1/100);
			System.out.printf(" Passenger load per bus: %5.0f%n" , q1*s);
			System.out.printf(" Value of objective function: $ %5.0f%n" , (B1/y + R1 - C1)/100);
			System.out.printf(" Transit deficit: $%5.0f%n" , (C1-R1)/100);
		}
	}

	public static void main(String[] args) {
		// Set y= 1000 or higher for profit maximization; y= 1 for net user benefit max; between 1 and 1000 to vary deficit constraint
		System.out.println("Profit maximization");
		BusDesignCartesian profitMax= new BusDesignCartesian(1000.0, 45, true, true);
		profitMax.optimize();

		System.out.println("\nBenefit maximization");
		BusDesignCartesian benefitMax= new BusDesignCartesian(1.0, 45, true, true);
		benefitMax.optimize();

		// Loop to find breakeven point, in general. This example just outputs the answer with y already set.

		System.out.println("\nBreakeven deficit constraint, no vehicle size constraint");
		BusDesignCartesian defConstraint= new BusDesignCartesian(1.28, 1000, true, false);
		defConstraint.optimize();

		System.out.println("\nBreakeven deficit constraint, vehicle size constraint");
		BusDesignCartesian defConstraint2= new BusDesignCartesian(1.43, 45, false, true);
		defConstraint2.optimize();
	}
}