package src.demand;
import src.linear.Gauss;
import src.newton.MathFunction2;

public class NewtonForDemand {
	private static double[][] fjac;		// Inelegant means to get fjac as well as x.
	// If fjac (Jacobian matrix) is not needed as output, eliminate this and
	// declare as local variable in mnewt()

	public static double[] mnewt(int nTrial, double[] x, MathFunction2 func) {
		final double TOLERANCE= 1E-13;
		int n= x.length;
		double[] p= new double[n];
		double[] fvec= new double[n];
		fjac= new double[n][n];
		for (int k= 0; k < nTrial; k++) {
			fvec= func.func(x);
			fjac= func.jacobian(x);
			double errf= 0.0;
			for (int i= 0; i < n; i++)
				errf += Math.abs(fvec[i]);
			if (errf < TOLERANCE)
				return x;
			for (int i= 0; i < n; i++) 
				p[i]= -fvec[i];
			p= Gauss.gaussian(fjac, p);
			double errx= 0.0;
			for (int i= 0; i < n; i++) {
				errx += Math.abs(p[i]);
				x[i] += p[i];
			}
			// Demo output for demand model example only. Remove for general use
			System.out.print(" Iteration "+ k);
			for (int i= 0; i < n; i++)
				System.out.print(" coeff " + i + " : "+ x[i]);
			System.out.println();
			// End demo output
			if (errx <= TOLERANCE)
				return x;
		}
		return x;
	}
	
	public static double[][] getFjac() {
		return fjac;
	}
}