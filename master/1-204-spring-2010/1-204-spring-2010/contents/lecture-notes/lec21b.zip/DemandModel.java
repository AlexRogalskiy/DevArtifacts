package src.demand;
import src.linear.Gauss;
import src.newton.MathFunction2;

public class DemandModel implements MathFunction2 {
	private double[][] x;		// Variables (constant, travel time) for each traveler
	private double[] y;			// Observed choice: 1 if auto, 0 if transit
	private double[] p;			// Probability of individual at each iteration (internal variable used for efficiency)

	public DemandModel(double[][] x, double[] y) {
		this.x = x;
		this.y = y;
		p= new double[y.length];
	}
	@Override
	public double[] func(double[] beta) {
		int n= y.length;						// Number of observations
		int k= beta.length;						// Number of parameters to estimate
		double[] f= new double[beta.length];
		for (int i= 0; i < n; i++) {			// Compute utility for individual, which depends on all variables/parameters
			double util= 0;
			for (int j= 0; j < k; j++) 
				util += beta[j]*x[i][j];
			p[i]= 1/(1 + Math.exp(-util));		// Compute estimated probability for individual
		}
		for (int j= 0; j < k; j++)				// Loop over equations (one per parameter to estimate)
			for (int i= 0; i < n; i++)			// Loop thru observations
				f[j] += (y[i]- p[i])*x[i][j];	// Compute likelihood equation for kth parameter (unknown)
		return f;
	}
	@Override
	public double[][] jacobian(double[] beta) {
		// MUST call func() before calling jacobian(). We don't check.
		int n= y.length;
		int k= beta.length;
		double[][] jac= new double[k][k];
		for (int j= 0; j < k; j++)
			for (int jj= 0; jj < k; jj++)
				for (int i= 0; i < n; i++)
					jac[j][jj] -= (p[i]*(1-p[i]))*x[i][j]*x[i][jj];
		return jac;
	}

	public double logLikelihood(double[] beta) {
		int n= y.length;
		int k= beta.length;
		double result= 0.0;
		for (int i= 0; i < n; i++) {			// Compute utility for individual, which depends on all variables/parameters
			double util= 0;
			for (int j= 0; j < k; j++) 
				util += beta[j]*x[i][j];
			p[i]= 1/(1 + Math.exp(-util));		// Compute estimated probability for individual
			result += y[i]*Math.log(p[i]) + (1-y[i])*Math.log(1-p[i]);
		}
		return result;
	}
	
	public void print(double log0, double logB, double[] beta, double[][] fjac) {
		System.out.println();		
		// Second derivatives: variance-covariance matrix
		int n= fjac.length;
		double[][] variance= Gauss.invert(fjac);
		for (int i= 0; i < n; i++)
			for (int j= 0; j < n; j++)
				variance[i][j]= -variance[i][j];
		
		for (int i= 0; i < beta.length; i++)
			System.out.println("Coefficient "+ i + " : "+ beta[i]+
					" Std. dev. "+ Math.sqrt(variance[i][i]));
		System.out.println("\nLog likelihood(0) "+ log0);
		System.out.println("Log likelihood(B) " + logB);
		System.out.println("-2[L(0)-L(B)]     " + -2.0*(log0-logB));
		System.out.println("Rho^2             " + (1.0 - logB/log0));
		System.out.println("Rho-bar^2         " + (1.0 - (logB-beta.length)/log0));
		
		System.out.println("\nVariance-covariance matrix");
		for (int i= 0; i < n; i++) {
			for (int j= 0; j < n; j++)
				System.out.print(variance[i][j]+" ");
			System.out.println();
		}
	}
}