package src.demand;

public class DemandModelTest {
	public static void main(String[] args) {
		double[][] x= { {1, 52.9 - 4.4},
				{1, 4.1 - 28.5},
				{1, 4.1 - 86.9},
				{1, 56.2 - 31.6},
				{1, 51.8 - 20.2},
				{1, 0.2 - 91.2},
				{1, 27.6 - 79.7},
				{1, 89.9 - 2.2},
				{1, 41.5 - 24.5},
				{1, 95.0 - 43.5},
				{1, 99.1 - 8.4},
				{1, 18.5 - 84.0},
				{1, 82.0 - 38.0},
				{1, 8.6 - 1.6},
				{1, 22.5 - 74.1},
				{1, 51.4 - 83.8},
				{1, 81.0 - 19.2},
				{1, 51.0 - 85.0},
				{1, 62.2 - 90.1},
				{1, 95.1 - 22.2},
				{1, 41.6 - 91.5}
		};
		double[] y= {0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1};
		
		DemandModel d= new DemandModel(x, y);
		int nTrial= 20;
		double[] beta= {0, 0};						// Initial guess
		double log0= d.logLikelihood(beta);
		beta= NewtonForDemand.mnewt(nTrial, beta, d);
		double logB= d.logLikelihood(beta);
		d.print(log0, logB, beta, NewtonForDemand.getFjac());
	}
}