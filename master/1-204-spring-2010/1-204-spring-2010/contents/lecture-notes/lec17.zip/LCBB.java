package src.bb;
// Uses BBNode nested class

import java.io.*;
import java.util.StringTokenizer;
import src.dataStructures.Heap;		// isEmpty() method added to class Heap
import src.greedy.Graph;

public class LCBB {
	// Input data
	private int nw;			// Number of potential warehouses
	private int nc; 		// Number of customers
	private int[] f;		// Fixed cost of each potential warehouse
	private int[][] c;		// Cost from each customer to each potential warehouse
	private int[] railcost;	// Cost by rail from warehouse to port
	private int[] prod;		// Production volume from each customer
	private final static int EPS= 1;				// Epsilon, tolerance
	private final static int MAXBBNODES= 10000;		// Max branch and bound nodes. Can use ArrayList instead.
	
	// Data used by branch and bound calculations
	private int[] savMax;	// Calculated by warehouseBound(), max savings of opening a warehouse
	private int[] savMin;	// Calculated by warehouseBound(), min savings of opening a warehouse
	private BBNode[] nodes;	// Branch and bound nodes, each with current solution, lower and upper bound
	private Heap h;			// Keeps nodes of branch and bound tree to be visited
	
	// Solution
	private int[] ans; 		// Solution: 1 if warehouse in solution, -1 if not (0 at intermediate point in alg)
	private int upperBound;	// Global upper bound, turns into solution value at end of algorithm
	private boolean optimumFound;	// Whether optimum was found (true) or terminated after max nodes searched
	int[] whAssign;			// Warehouse assigned to each customer (output)
	int[] flow;				// Flow through each warehouse(output)
	
	@SuppressWarnings("unchecked")
	private class BBNode implements Comparable {
		private int[] x;		// Solution at each node in branch and bound tree
		private int upBound;	// Upper bound (cost) estimate at each BB node
		private int lowBound;	// Lower bound (cost) estimate at each BB node
		
		public BBNode() {
			x= new int[nw];
		}
		@Override
		public int compareTo(Object other) {	// Want lowest lower bound on top of heap. Check this.
			BBNode o= (BBNode) other;
			if (lowBound < o.lowBound)
				return 1;
			else if (lowBound > o.lowBound)
				return -1;
			else
				return 0;
		}
	}

	public LCBB(String filename) {
		// Input data
		bbNetwork(filename);
		c= new int[nw+1][nc];				// Cost matrix computed from production costs, network costs

		// Data used by branch and bound calculations
		savMax= new int[nw];
		savMin= new int[nw];
		nodes= new BBNode[MAXBBNODES];
		for (int i= 0; i < MAXBBNODES; i++)	// Allocate all BBNode memory first. Java efficiency isn't good for this
			nodes[i]= new BBNode();
		h= new Heap();

		// Solution
		ans= new int[nw];
		upperBound= Integer.MAX_VALUE;		// Initialize upper bound to infinity
		whAssign= new int[nc];
		flow= new int[nw];
	}
	
	public void bbNetwork(String filename) {
		try {
			FileReader fin= new FileReader(filename);
			BufferedReader in= new BufferedReader(fin);
			nc= Integer.parseInt(in.readLine());
			nw= Integer.parseInt(in.readLine());
			f= new int[nw];
			railcost= new int[nw];
			prod= new int[nc+nw];		// Production at warehouses=0 but it's convenient to loop over all nodes
			for (int i=0; i < nw; i++) {
				String str = in.readLine();
				StringTokenizer t = new StringTokenizer(str, ",");
				int wNumber= (Integer.parseInt(t.nextToken()));		// Ignored, assumed in order
				railcost[i]= (Integer.parseInt(t.nextToken()));
				f[i]= (Integer.parseInt(t.nextToken()));
			}
			for (int i= 0; i < nc; i++) {
				String str = in.readLine();
				StringTokenizer t = new StringTokenizer(str, ",");
				int cNumber= (Integer.parseInt(t.nextToken()));		// Ignored, assumed in order
				prod[i]= (Integer.parseInt(t.nextToken()));
			}
			in.close();
		} catch(IOException e) {
			System.out.println(e);
		}
	}
	
	public void setC(Graph g) {
		int[][] DW= new int[nw+1][nc+nw];
		int[][] PW= new int[nw+1][nc+nw];
		int nodes= g.getNodes();
		
		for (int root= nc; root < (nc + nw); root++) { 
			g.shortHK(root);
			int[] D= g.getD();
			int[] P= g.getP();
			for (int i= 0; i < nodes; i++) {
				DW[root-nc][i]= D[i];
				PW[root-nc][i]= P[i];
			}
		}
		for (int k= 0; k < nw; k++)
			for (int j= 0; j < nc; j++)
				c[k][j]= (DW[k][j] + railcost[k])* prod[j];
	}
	
	public void initializeBB() {
		for (int m= 0; m < nc; m++) {		// Write highest cost from any non-closed warehouse to
			int temp= 0;					// each customer in nw'th line of c (cost)
			for (int j= 0; j < nw; j++)		// array. Helps bound method calculations
				if (c[j][m] > temp)
					temp= c[j][m];
			c[nw][m]= temp;
		}

		if (bound(0)) {						// Find upper, lower bounds at root. Bound returns true if root is leaf node
			upperBound= nodes[0].lowBound;	// Set upper bound to root cost
			for (int k= 0; k < nw ; k++)	// Set answer array to root's solution x
				ans[k]= nodes[0].x[k];
		}
		// If all warehouses closed at root, select cheapest one. This special case not handled.
	}

	public boolean bb() {
		BBNode eNode= nodes[0];					// Root, node 0, is the first e-node
		int i= 0;								// Root is 0th node in tree
		int inOut= 1;							// Toggles between -1 (left child) and +1 (right child)
		do {									// Infinite loop until queue empty
			int w= -1;
			do {								// Find first warehouse with unknown status
				w++;
			} while (!(eNode.x[w] == 0 || w >= nw));
			if (w < nw) {						// If unknown warehouse found, generate children
				for (int z=0; z <=1; z++) {	
					i++;						// Generate child. 
					for (int j= 0; j < nw; j++)
						nodes[i].x[j]= eNode.x[j];			// Copy parent's solution state
					nodes[i].x[w]= -inOut;					// Set unknown warehouse closed (left child) or open (right child)		
					boolean leaf= bound(i);					// Bound this child node, returns true if child node is leaf
					if (nodes[i].lowBound < upperBound) {	// If worth expanding
						if (leaf) {							// If child is leaf, we have new optimum
							upperBound= nodes[i].lowBound;	// Update upper bound
							for (int k= 0; k < nw; k++)
								ans[k]= nodes[i].x[k];		// Update solution
						} else {							// Child is not leaf
							h.insert(nodes[i]);				// Add to heap to explore further
							if (nodes[i].upBound + EPS < upperBound)	// Make sure non-leaf doesn't prune leaf solution
								upperBound= nodes[i].upBound + EPS;		// Update upper bound (but not solution)
						}
					}
				}
			}
			do {										// Find new e-node
				if (h.isEmpty())						// If heap empty, we're done
					return true;						// Found optimum
				eNode= (BBNode) h.delete();			// Get e-node from front of heap
			} while (eNode.lowBound >= upperBound);	// If node's lower bound > upper bound, get next node 
		} while (i < MAXBBNODES-2);				// Quit 1 node early so we don't exceed size of x array
		return false;							// Generated maximum number of nodes without finding optimum
	}

	
	private boolean bound(int i) {				// Returns true if leaf node
		boolean change;		
		do {									// Try to lock in or lock out warehouses based on max/min savings
			change= false;
			for (int k= 0; k < nw; k++)
				if (nodes[i].x[k] == 0) 
					warehouseBound(i, k);		// Find min, max savings from opening this warehouse
			for (int k= 0; k < nw; k++) {
				if (nodes[i].x[k] == 0) {
					if (savMin[k] - f[k] >= 0) {
						change= true;
						nodes[i].x[k]= 1;			// Lock in warehouse
						for (int j= 0; j < nc; j++)
							if (c[k][j] < c[nw][j])
								c[nw][j] = c[k][j];
					}
					if (savMax[k] - f[k] <= 0) {
						change= true;
						nodes[i].x[k]= -1;		// Lock out warehouse
					}
				}
			}
		} while (change);
		
		// Compute lower and upper bound. Start by adding up transportation costs over all customers to non-closed warehouses
		int lowc= 0, minc= 0, uppc= 0, maxc= 0;
		for (int j= 0; j < nc; j++) {
			minc= Integer.MAX_VALUE;
			maxc= c[nw][j];
			for (int k= 0; k < nw; k++) 
				if ((nodes[i].x[k] != -1) && (c[k][j] < minc)) 
					minc= c[k][j];		// Find min transportation cost for rest of tree
			if (minc == Integer.MAX_VALUE)
				minc= 0;
			lowc += minc;
			uppc += maxc;
		}
		
		// Add fixed costs of open warehouses to lower and upper bounds, fixed cost of unknown warehouses to upper bound
		boolean leaf= true;
		for (int k= 0; k < nw; k++) {
			if (nodes[i].x[k] == 1) {
				lowc += f[k];
				uppc += f[k];
			}
			if (nodes[i].x[k] == 0) {
				leaf= false;
				uppc += f[k];
			}
		}
		nodes[i].lowBound = lowc;
		nodes[i].upBound = uppc;
		return leaf;
	}
	
	private void warehouseBound(int i, int wh) {
		// Find minimum and maximum savings for a warehouse
		// i= current node, wh= warehouse being examined
		int minSav= 0;
		int maxSav= 0;
		for (int h= 0; h < nc; h++) {		// Loop thru each customer
			minSav= Integer.MAX_VALUE;
			if (c[wh][h] < c[nw][h]) 
				maxSav= c[nw][h] - c[wh][h];
			else
				maxSav= 0;
			for (int g= 0; g < nw ; g++)	// Loop thru each warehouse
				if ((g != wh) && (nodes[i].x[g] != -1) && ((c[g][h] - c[wh][h]) < minSav))
					minSav= c[g][h] - c[wh][h];
			if (minSav == Integer.MAX_VALUE || minSav < 0 )
				minSav= 0;
			savMin[wh] += minSav;
			savMax[wh] += maxSav;
		}
	}

	public void bbAssign() {
		for (int k= 0; k < nc; k++) {
			int temp= Integer.MAX_VALUE;
			for (int j= 0; j < nw; j++) {
				if (c[j][k] < temp  && ans[j]== 1) {
					temp= c[j][k];
					whAssign[k]= j;
				}
			}
		}
		for (int k=0; k < nc; k++)
			flow[whAssign[k]] += prod[k];
	}
	
	public void bbOutput() {
		System.out.println("Optimum found? "+ optimumFound);
		if (!optimumFound) {	// This code only lightly tested 
			System.out.println("Upper bound: " + upperBound);
			// Go through all E nodes in heap to find lowest lower bound
			int lowerBound= Integer.MAX_VALUE;
			while (!h.isEmpty()) {
				BBNode n= (BBNode) h.delete();
				if (n.lowBound < lowerBound)
					lowerBound= n.lowBound;
			}
			System.out.println("Lower bound: " + lowerBound);
		}	
		// If no leaf node has been visited yet, answer array will be all zeros.
		// Can insert code here to set ans array= x array of node with best lower bound. Not done.
		
		int constr= 0;
		System.out.println("\nCenter \tConstruct? \tFixed Cost");
		for (int j= 0; j < nw; j++) {
			System.out.println(j+"\t\t"+ ans[j]+ "\t\t"+ f[j]);
			if (ans[j] == 1)
				constr += f[j];
		}
		int trans= upperBound - constr;
		System.out.println("\nTransport cost: "+ trans +" fixed cost: "+ constr);

		System.out.println("\nFlow through consolidation centers");
		System.out.println("Center\tTons");
		for (int j= 0; j < nw ; j++)
			System.out.println(j + "\t"+ flow[j]);

		for (int j= 0; j < nw; j++)
			if (ans[j] == 1) {
				System.out.println("\nAreas that ship to center "+ j);
				for (int k= 0; k < nc; k++)
					if (whAssign[k] == j)
						System.out.print(" " + k);
			}
	}
	
	public void branchAndBound(Graph g) {
		setC(g);
		initializeBB();
		optimumFound= bb();
		bbAssign();
		bbOutput();
	}

	public static void main(String[] args) {
		Graph g= new Graph("src/bb/graph.txt");
		LCBB w= new LCBB("src/bb/warehouse.txt");
		w.branchAndBound(g);
	}
}