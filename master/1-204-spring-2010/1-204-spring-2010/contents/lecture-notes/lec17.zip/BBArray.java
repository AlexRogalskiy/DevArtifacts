package src.bb;

import java.io.*;
import java.util.StringTokenizer;
import src.dataStructures.Queue;
import src.greedy.Graph;

public class BBArray {
	// Input data
	private int nw;			// Number of potential warehouses
	private int nc; 		// Number of customers
	private int[] f;		// Fixed cost of each potential warehouse
	private int[][] c;		// Cost from each customer to each potential warehouse
	private int[] railcost;	// Cost by rail from warehouse to port
	private int[] prod;		// Production volume from each customer
	private final static int EPS= 1;				// Epsilon, tolerance
	private final static int MAXBBNODES= 10000;		// Max branch and bound nodes. Can use ArrayList instead.
	
	// Data used by branch and bound calculations
	private int[] savMax;	// Calculated by warehouseBound(), max savings of opening a warehouse
	private int[] savMin;	// Calculated by warehouseBound(), min savings of opening a warehouse
	private int[][] x;		// Solution at each node in branch and bound tree
	private int[] upBound;	// Upper bound (cost) estimate at each BB node
	private int[] lowBound;	// Lower bound (cost) estimate at each BB node
	private Queue q;		// Keeps nodes of branch and bound tree to be visited
	
	// We could place x, upBound, lowBound into an inner or nested class BBNode
	// This would allow us to use a heap and create a priority criterion for LC-search (or still use queues or stacks)
	// To do this, we must allocate an array of BBNodes AND allocate all the BBNodes at the same time.
	// It's too slow to allocate BBNodes one by one as they are needed.  Not done in this version, but straightforward.
	
	// Solution
	private int[] ans; 		// Solution: 1 if warehouse in solution, -1 if not (0 at intermediate point in algorithm)
	private int upperBound;	// Global upper bound, turns into solution value at end of algorithm
	private boolean optimumFound;	// Whether optimum was found (true) or terminated after max nodes searched
	int[] whAssign;			// Warehouse assigned to each customer (output)
	int[] flow;				// Flow through each warehouse(output)

	public BBArray(String filename) {
		// Input data
		bbNetwork(filename);
		c= new int[nw+1][nc];				// Cost matrix computed from production costs, network costs

		// Data used by branch and bound calculations
		savMax= new int[nw];				// Max savings from opening a warehouse, contingent on other warehouses' status
		savMin= new int[nw];				// Min savings from opening a warehouse, contingent on other warehouses' status
		x= new int[MAXBBNODES][nw];			// Current solution at this node
		upBound= new int[MAXBBNODES];		// Upper bound at this node
		lowBound= new int[MAXBBNODES];		// Lower bound at this node
		q= new Queue();						// Queue of branch and bound nodes still to be examined

		// Solution
		ans= new int[nw];					// Current best answer, optimum at termination
		upperBound= Integer.MAX_VALUE;		// Initialize upper bound to infinity
		whAssign= new int[nc];				// Warehouse that handles each customer
		flow= new int[nw];					// Flow through warehouse from all its customers
	}
	
	public void bbNetwork(String filename) {
		try {
			FileReader fin= new FileReader(filename);
			BufferedReader in= new BufferedReader(fin);
			nc= Integer.parseInt(in.readLine());		// Number of customers
			nw= Integer.parseInt(in.readLine());		// Number of potential warehouses
			f= new int[nw];								// Fixed (capital) cost of each warehouse
			railcost= new int[nw];						// Rail cost to port from each warehouse
			prod= new int[nc+nw];		// Production at warehouses=0 but it's convenient to loop over all nodes
			for (int i=0; i < nw; i++) {
				String str = in.readLine();
				StringTokenizer t = new StringTokenizer(str, ",");
				int wNumber= (Integer.parseInt(t.nextToken()));		// Ignored, assumed in order
				railcost[i]= (Integer.parseInt(t.nextToken()));
				f[i]= (Integer.parseInt(t.nextToken()));
			}
			for (int i= 0; i < nc; i++) {
				String str = in.readLine();
				StringTokenizer t = new StringTokenizer(str, ",");
				int cNumber= (Integer.parseInt(t.nextToken()));		// Ignored, assumed in order
				prod[i]= (Integer.parseInt(t.nextToken()));			// Production from each warehouse customer
			}
			in.close();
		} catch(IOException e) {
			System.out.println(e);
		}
	}
	
	public void setC(Graph g) {
		int[][] DW= new int[nw+1][nc+nw];		// Distance to each warehouse from each customer
		int[][] PW= new int[nw+1][nc+nw];		// Predecessor for each node (customer) in shortest path to warehouse
		int nodes= g.getNodes();				// Number of nodes in graph
		
		for (int root= nc; root < (nc + nw); root++) { 	// Loop thru all warehouses
			g.shortHK(root);							// Find shortest path from each warehouse to each customer
			int[] D= g.getD();							// Get distances from warehouse (shortest path root) to all other nodes
			int[] P= g.getP();							// Get predecessors from warehouse to all other nodes
			for (int i= 0; i < nodes; i++) {			// Copy each warehouse's root into DW and PW 2-D arrays
				DW[root-nc][i]= D[i];
				PW[root-nc][i]= P[i];
			}
		}
		for (int k= 0; k < nw; k++)							// To each warehouse
			for (int j= 0; j < nc; j++)						// From each customer
				c[k][j]= (DW[k][j] + railcost[k])* prod[j];	// Add rail cost from warehouse to port + transport cost cust-warehouse
	}
	
	public void initializeBB() {
		for (int m= 0; m < nc; m++) {		// Write highest cost from any non-closed warehouse to
			int temp= 0;					// each customer in nw'th line of c (cost)
			for (int j= 0; j < nw; j++)		// array. Helps bound method calculations
				if (c[j][m] > temp)
					temp= c[j][m];
			c[nw][m]= temp;
		}

		if (bound(0)) {						// Find upper, lower bounds at root. Bound returns true if root is leaf node
			upperBound= lowBound[0];		// Set upper bound to root cost
			for (int k= 0; k < nw ; k++)	// Set answer array to root's solution x
				ans[k]= x[0][k];
		}
		// If all warehouses closed at root, select cheapest one. This special case not handled.
	}

	public boolean bb() {
		int eNode= 0;							// Root, node 0, is the first e-node
		int i= 0;								// Root is 0th node in tree
		int inOut= 1;							// Toggles between -1 (left child) and +1 (right child)
		do {									// Infinite loop until queue empty
			int w= -1;
			do {								// Find first warehouse with unknown status
				w++;
			} while (!(x[eNode][w] == 0 || w >= nw));
			if (w < nw) {						// If unknown warehouse found, generate children
				for (int z=0; z <=1; z++) {	
					i++;						// Generate child. Should check that x array large enough
					for (int j= 0; j < nw; j++)
						x[i][j]= x[eNode][j];	// Copy parent's solution state
					x[i][w]= -inOut;			// Set unknown warehouse closed (left child) or open (right child)		
					boolean leaf= bound(i);				// Bound this child node, returns true if child node is leaf
					if (lowBound[i] < upperBound) {		// If worth expanding
						if (leaf) {						// If child is leaf, we have new optimum
							upperBound= lowBound[i];	// Update upper bound
							for (int k= 0; k < nw; k++)
								ans[k]= x[i][k];		// Update solution
						} else {						// Child is not leaf
							q.add(i);					// Add to queue to explore further
							if (upBound[i] + EPS < upperBound)
								upperBound= upBound[i] + EPS;	// Update upper bound (but not solution)
						}
					}
				}
			}
			do {										// Find new e-node
				if (q.isEmpty())						// If queue empty, we're done
					return true;						// Found optimum
				eNode= (Integer) q.remove();			// Get e-node from front of queue
			} while (lowBound[eNode] >= upperBound);	// If node's lower bound > upper bound, get next node 
		} while (i < MAXBBNODES-2);				// Quit 1 node early so we don't exceed size of x array
		return false;							// Generated maximum number of nodes without finding optimum
	}

	
	private boolean bound(int i) {				// Returns true if leaf node
		boolean change;		
		do {									// Try to lock in or lock out warehouses based on max/min savings
			change= false;
			for (int k= 0; k < nw; k++)			// Loop thru all warehouses
				if (x[i][k] == 0) 				// If warehouse status unknown
					warehouseBound(i, k);		// Find min, max savings from opening this warehouse
			for (int k= 0; k < nw; k++) {		// Loop thru all warehouses again
				if (x[i][k] == 0) {				// If warehouse status unknown
					if (savMin[k] - f[k] >= 0) {	// If min savings greater than fixed cost, lock in warehouse
						change= true;
						x[i][k]= 1;					// Lock in warehouse
						for (int j= 0; j < nc; j++)	// Update nw'th column in c for this warehouse being out
							if (c[k][j] < c[nw][j])
								c[nw][j] = c[k][j];
					}
					if (savMax[k] - f[k] <= 0) {	// If max savings less than fixed cost, 
						change= true;
						x[i][k]= -1;		// Lock out warehouse
					}
				}
			}
		} while (change);
		
		// Compute lower and upper bound. Start by adding up transportation costs over all customers to non-closed warehouses
		int lowc= 0, minc= 0, uppc= 0, maxc= 0;
		for (int j= 0; j < nc; j++) {		// Loop thru all customers
			minc= Integer.MAX_VALUE;		// Assume lower bound transport cost component is +infinity, to start
			maxc= c[nw][j];					// Assume upper bound transport cost component is max cost, via open whses only
			for (int k= 0; k < nw; k++) 
				if ((x[i][k] != -1) && (c[k][j] < minc)) 
					minc= c[k][j];		// Find min transportation cost for rest of branch and bound tree (open, unknown whses)
			if (minc == Integer.MAX_VALUE)
				minc= 0;				// If no open, unknown whses, lower bound transport cost= 0
			lowc += minc;				// Add this customer's min transport cost to lower bound 
			uppc += maxc;				// Add this customer's max transport cost to upper bound
		}
		
		// Add fixed costs of open warehouses to lower and upper bounds, fixed cost of unknown warehouses to upper bound
		boolean leaf= true;
		for (int k= 0; k < nw; k++) {
			if (x[i][k] == 1) {			// If warehouse open, add its fixed cost
				lowc += f[k];
				uppc += f[k];
			}
			if (x[i][k] == 0) {			// If warehouse unknown, add its fixed cost to upper bound only
				leaf= false;
				uppc += f[k];			// Not a leaf node, since at least one unknown warehouse exists at this b-and-b node
			}
		}
		lowBound[i] = lowc;				// Save the lower and upper bounds
		upBound[i] = uppc;
		return leaf;
	}
	
	private void warehouseBound(int i, int wh) {
		// Find minimum and maximum savings for a single warehouse
		// i= current node, wh= warehouse being examined
		int minSav= 0;
		int maxSav= 0;
		for (int h= 0; h < nc; h++) {		// Loop thru each customer
			minSav= Integer.MAX_VALUE;
			if (c[wh][h] < c[nw][h]) 		// If cost less than max cost (thru cheapest open warehouse)
				maxSav= c[nw][h] - c[wh][h];	// Max savings is cost difference
			else
				maxSav= 0;
			for (int g= 0; g < nw ; g++)	// Loop thru other warehouses. If other warehouse open or unknown
				if ((g != wh) && (x[i][g] != -1) && ((c[g][h] - c[wh][h]) < minSav))	// and its cost difference is smaller
					minSav= c[g][h] - c[wh][h];											// than found before, update min savings
			if (minSav == Integer.MAX_VALUE || minSav < 0 )								// of opening this warehouse
				minSav= 0;					// If no open or unknown warehouse found with higher costs than this one, zero min savings
			savMin[wh] += minSav;			// Add this customer's min savings to total for warehouse
			savMax[wh] += maxSav;			// Add this customer's max savings to total for warehouse
		}
	}

	public void bbAssign() {
		for (int k= 0; k < nc; k++) {		// Loop through all customers
			int temp= Integer.MAX_VALUE;
			for (int j= 0; j < nw; j++) {	// Loop through all warehouses
				if (c[j][k] < temp  && ans[j]== 1) {	// If warehouse open and cost from cust to warehouse is smaller
					temp= c[j][k];						// Store cheapest cost
					whAssign[k]= j;						// Assign customer to this warehouse
				}
			}
		}
		for (int k=0; k < nc; k++)			// Loop through all customers
			flow[whAssign[k]] += prod[k];	// Add up their flow (production) to their assigned warehouse
	}
	
	public void bbOutput() {
		System.out.println("Optimum found? "+ optimumFound);
		if (!optimumFound) {	// This code only lightly tested 
			System.out.println("Upper bound: " + upperBound);
			// Go through all E nodes in queue to find lowest lower bound
			int lowerBound= Integer.MAX_VALUE;
			while (!q.isEmpty()) {
				int node= (Integer) q.remove();
				if (lowBound[node] < lowerBound)
					lowerBound= lowBound[node];
			}
			System.out.println("Lower bound: " + lowerBound);
		}	
		// If no leaf node has been visited yet, answer array will be all zeros.
		// Can insert code here to set ans array= x array of node with best lower bound. Not done.
		
		int constr= 0;
		System.out.println("\nCenter \tConstruct? \tFixed Cost");
		for (int j= 0; j < nw; j++) {			// Loop through all warehouses
			System.out.println(j+"\t\t"+ ans[j]+ "\t\t"+ f[j]);
			if (ans[j] == 1)					// Print fixed (capital) cost if open
				constr += f[j];
		}
		int trans= upperBound - constr;			// Total transport costs= total costs - total fixed costs
		System.out.println("\nTransport cost: "+ trans +" fixed cost: "+ constr);

		System.out.println("\nFlow through consolidation centers");
		System.out.println("Center\tTons");
		for (int j= 0; j < nw ; j++)
			System.out.println(j + "\t"+ flow[j]);

		for (int j= 0; j < nw; j++)
			if (ans[j] == 1) {
				System.out.println("\nAreas that ship to center "+ j);
				for (int k= 0; k < nc; k++)
					if (whAssign[k] == j)
						System.out.print(" " + k);
			}
	}
	
	public void branchAndBound(Graph g) {
		setC(g);
		initializeBB();
		optimumFound= bb();
		bbAssign();
		bbOutput();
	}

	public static void main(String[] args) {
		Graph g= new Graph("src/bb/graph.txt");
		BBArray w= new BBArray("src/bb/warehouse.txt");
		w.branchAndBound(g);
	}
}