package src.dp;

public class MultiStageGraph {
	private static class Node {
		private int projNbr;		// Project number, 0 through numProj-1, for which this is start node
		private int cumResource;	// Units of resource allocated so far, at this node
		private int cumProfit;		// Profit so far, at this node
		private Node predecessor;	// Previous node on highest profit path to this node

		public Node(int proj, int res, int prof, Node p) {
			projNbr= proj;
			cumResource= res;
			cumProfit= prof;
			predecessor= p;
		}
	}
	
	private int numProj;	// No of projects
	private int n; 			// Max units of resource + 1 (e.g.,if 4 units max, store 0 thru 4 data)
	private Node root; 		// First node in graph
	private Node sink; 		// Last node in graph
	
	public MultiStageGraph(int np, int n) {
		this.numProj = np;
		this.n = n;			// root, sink null initially
	}
	
	public int getNumProj() {
		return numProj;
	}
	
	public int getMaxResource() {
		return n;
	}
	
	public void buildGraph(int[][] p) {
		Node[] prevStage = new Node[n]; 	// Store previous stage nodes; need at next stage
		Node[] currStage = new Node[n]; 	// Store current stage nodes
		root = new Node(0, 0, 0, null); 	// Project (stage) 0 start node, units so far 0, profit so far 0
		
		Node currentNode= null;
		// Project (stage) 1 start nodes as special case, since they have single arcs back to root
		for (int i = 0; i < n; i++) {
			currentNode = new Node(1, i, p[0][i], root);	// Stage 1 start node has stage 0 profit
			prevStage[i] = currentNode;
		}
		
		// Project (stage) 2 start nodes thru project (stage) M-1 start nodes
		for (int i = 2; i < numProj; i++) {
			// Loop, giving 0-> n resources to project
			for (int j = 0; j < n; j++) {
				currentNode = new Node(i, j, 0, null);
				currStage[j] = currentNode;
				for (int k = 0; k <= j; k++) {	// Arcs from prev stage up to resource k
					Node pastNode = prevStage[j - k];
					int profit= p[i-1][k];
					int cumProfit = profit + pastNode.cumProfit;
					if (cumProfit >= currentNode.cumProfit) {
						currentNode.cumProfit=cumProfit;
						currentNode.predecessor=pastNode;
					}
				}
			}
			// Copy current node array into previous node array at end of each stage
			for (int j = 0; j < n; j++) { 
				prevStage[j] = currStage[j];
			}
		}
		// Create the sink or last node, an 'artificial' project M
		sink = new Node(numProj + 1, n-1, 0, null);
		// Mth project, n units resource, 0 profit
		for (int i = 0; i < n; i++) { 	// Loop thru nodes at M-1 with cum resources 0 thru n
			int j= n-1-i;				// Apply max units possible to M-1 project. Don't check if smaller units give higher profit
			Node pastNode = prevStage[i];
			int profit= p[numProj-1][j];
			int cumProfit = profit + pastNode.cumProfit;				
			if (cumProfit >= sink.cumProfit) {
				sink.cumResource= j + pastNode.cumResource;
				sink.cumProfit= cumProfit;
				sink.predecessor= pastNode;
			}
		}
		return;
	}

	public int backwardPass() {
		// A better implementation would return a 2-D array of (resources, profit) for each project
		System.out.println("Problem solution:");
		System.out.println(" Total profit: " + sink.cumProfit);
		System.out.println(" Total units allocated: " + sink.cumResource+"\n");
		Node next= sink;
		Node current= sink.predecessor;
		
		while (current != null) {
			System.out.println("Project: "+ current.projNbr);	// Project number
			int units= next.cumResource - current.cumResource;	// Diff in units is proj units
			int profit= next.cumProfit - current.cumProfit;		// Diff in profit is proj prof
			System.out.println(" Units: "+ units);
			System.out.println(" Profit: "+ profit);
			next= current;
			current= current.predecessor;
		}
		return sink.cumProfit;
	}
	
	public static void main(String[] args) {
		int numProjects= 3;
		int maxResource= 4;				
		int[][] p2= {{0,6,8,8,10},		// Project 0 profits 
				{0,5,11,16,17},			// Project 1 profits
				{0,1,4,5,6},};			// Project 2 profits
		// Increment maxResource: e.g., if maxResource=4, we have 5 decision levels (0,1,2,3,4)
		MultiStageGraph g2= new MultiStageGraph(numProjects, ++maxResource);
		g2.buildGraph(p2);
		int totalProfit= g2.backwardPass();
		System.out.println("Total profit: "+ totalProfit);
	}	
}