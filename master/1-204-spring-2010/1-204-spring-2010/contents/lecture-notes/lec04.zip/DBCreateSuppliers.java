package src.db;
import java.sql.*;

// JDBC book example on page 92
public class DBCreateSuppliers {
	public static void main(String[] args) {
		String url= "jdbc:sqlserver://localhost\\SQLEXPRESS;databaseName=MIT1204;"+
			"user=gkocur3;password=car5940;";
		Connection con;
		String createString = "create table SUPPLIERS " + 
			"(SUP_ID int, " +
			"SUP_NAME varchar(40), " +
			"STREET varchar(40), " +
			"CITY varchar(20), " +
			"STATE char(2), ZIP char(5))";
		Statement stmt;

		try {
			Class.forName( "com.microsoft.sqlserver.jdbc.SQLServerDriver" );
		} catch (ClassNotFoundException e) {
			System.out.println("ClassNotFoundException");
			e.printStackTrace();
		}

		try {       
			con = DriverManager.getConnection(url);
			System.out.println("Connected");		// Debug statement
			stmt= con.createStatement();
			stmt.executeUpdate(createString);
			stmt.close();
			con.close();
		} catch( SQLException ex ) {
			System.out.println("SQLException");
			ex.printStackTrace();
		}
	}
}