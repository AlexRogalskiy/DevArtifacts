package src.db;
import java.sql.*;

public class DBMetadata {
	public static void main(String[] args) {
		try {
			java.lang.Class.forName( "com.microsoft.sqlserver.jdbc.SQLServerDriver" );
			Connection c = java.sql.DriverManager.getConnection(
					"jdbc:sqlserver://localhost\\SQLEXPRESS;databaseName=MIT1204;user=gkocur3;password=car5940;" );
			System.out.println( "Connected!" );
			DatabaseMetaData meta = c.getMetaData();
			System.out.println("\nDriver Information");
			System.out.println("Driver Name: " + meta.getDriverName());
			System.out.println("Driver Version: " + meta.getDriverVersion());
			System.out.println("Driver supports generated keys: " + meta.supportsGetGeneratedKeys());
			System.out.println("\nDatabase Information ");
			System.out.println("Database Name: " + meta.getDatabaseProductName());
			System.out.println("Database Version: " + meta.getDatabaseProductVersion());
			c.close();
		} catch( Exception ex ) {
			ex.printStackTrace();
		}
	}
}