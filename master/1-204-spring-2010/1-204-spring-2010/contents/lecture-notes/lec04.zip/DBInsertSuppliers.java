package src.db;
import java.sql.*;

// JDBC book example on page 93
public class DBInsertSuppliers {
	public static void main(String[] args) {
		String url= "jdbc:sqlserver://localhost\\SQLEXPRESS;databaseName=MIT1204;"+
			"user=gkocur3;password=car5940;";
		Connection con;
		String query= "SELECT SUP_NAME, SUP_ID FROM SUPPLIERS";
		Statement stmt;

		try {
			Class.forName( "com.microsoft.sqlserver.jdbc.SQLServerDriver" );
		} catch (ClassNotFoundException e) {
			System.out.println("ClassNotFoundException");
			e.printStackTrace();
		}

		try {       
			con = DriverManager.getConnection(url);
			System.out.println("Connected");		// Debug statement
			stmt= con.createStatement();
			stmt.executeUpdate("insert into SUPPLIERS " +
	                 "values(49, 'Superior Coffee', '1 Party Place', " +
				 "'Mendocino', 'CA', '95460')");		
			stmt.executeUpdate("insert into SUPPLIERS " +
				"values(101, 'Acme, Inc.', '99 Market Street', " +
				"'Groundsville', 'CA', '95199')");
			stmt.executeUpdate("insert into SUPPLIERS " +
	                 "values(150, 'The High Ground', '100 Coffee Lane', " +
				 "'Meadows', 'CA', '93966')");
			ResultSet rs= stmt.executeQuery(query);
			System.out.println("Suppliers and their ID Numbers");
			while (rs.next()) {
				String s = rs.getString("SUP_NAME");
				int n = rs.getInt("SUP_ID");
				System.out.println(s + "   " + n);
			}
			stmt.close();
			con.close();
		} catch( SQLException ex ) {
			System.out.println("SQLException");
			ex.printStackTrace();
		}
	}
}