package src.db;
import java.sql.*;

// JDBC book example on page 89
public class DBInsertCoffee {
	public static void main(String[] args) {
		String url= "jdbc:sqlserver://localhost\\SQLEXPRESS;databaseName=MIT1204;"+
			"user=gkocur3;password=car5940;";
		Connection con;
		String query= "SELECT COF_NAME, PRICE FROM COFFEES";
		Statement stmt;

		try {
			Class.forName( "com.microsoft.sqlserver.jdbc.SQLServerDriver" );
		} catch (ClassNotFoundException e) {
			System.out.println("ClassNotFoundException");
			e.printStackTrace();
		}

		try {       
			con = DriverManager.getConnection(url);
			System.out.println("Connected");		// Debug statement
			stmt= con.createStatement();
			stmt.executeUpdate("INSERT INTO COFFEES " +
				"VALUES('Colombian', 101, 7.99, 0, 0)");
			stmt.executeUpdate("INSERT INTO COFFEES " +
				"VALUES('French_Roast', 49, 8.99, 0, 0)");
			stmt.executeUpdate("INSERT INTO COFFEES " +
				"VALUES('Espresso', 150, 9.99, 0, 0)");
			stmt.executeUpdate("INSERT INTO COFFEES " +
				"VALUES('Colombian_Decaf', 101, 8.99, 0, 0)");
			stmt.executeUpdate("INSERT INTO COFFEES " +
				"VALUES('French_Roast_Decaf', 49, 9.99, 0, 0)");
			ResultSet rs= stmt.executeQuery(query);
			System.out.println("Coffee Break Coffees and Prices");
			while (rs.next()) {
				String s= rs.getString("COF_NAME");
				float f= rs.getFloat("PRICE");
				System.out.println(s + " " + f);
			}
			stmt.close();
			con.close();
		} catch( SQLException ex ) {
			System.out.println("SQLException");
			ex.printStackTrace();
		}
	}
}