package src.db;
import java.sql.*;

// JDBC book example on page 88
public class DBCreateCoffees {
	public static void main(String[] args) {
		String url= "jdbc:sqlserver://localhost\\SQLEXPRESS;databaseName=MIT1204;"+
			"user=gkocur3;password=car5940;";
		Connection con;
		String createString= "CREATE TABLE COFFEES " +
			"(COF_NAME VARCHAR(32), SUP_ID INTEGER, PRICE FLOAT, " +
			"SALES INTEGER, TOTAL INTEGER)";
		Statement stmt;

		try {
			Class.forName( "com.microsoft.sqlserver.jdbc.SQLServerDriver" );
		} catch (ClassNotFoundException e) {
			System.out.println("ClassNotFoundException");
			e.printStackTrace();
		}

		try {       
			con = DriverManager.getConnection(url);
			System.out.println("Connected");		// Debug statement
			stmt= con.createStatement();
			stmt.executeUpdate(createString);
			stmt.close();
			con.close();
		} catch( SQLException ex ) {
			System.out.println("SQLException");
			ex.printStackTrace();
		}
	}
}