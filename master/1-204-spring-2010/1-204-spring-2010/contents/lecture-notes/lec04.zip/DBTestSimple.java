// Very simple test. Use to debug logging into new database.
package src.db;
import java.sql.*;

public class DBTestSimple {
   public static void main(String[] args) {
      try {
         java.lang.Class.forName( "com.microsoft.sqlserver.jdbc.SQLServerDriver" );
         Connection c = java.sql.DriverManager.getConnection(
        		 "jdbc:sqlserver://localhost\\SQLEXPRESS;databaseName=MIT1204;"+
        		 "user=gkocur3;password=car5940;" );
         System.out.println( "Connected!" );
         c.close();
      }
      catch( Exception ex )
      {
         ex.printStackTrace();
      }
   }
}