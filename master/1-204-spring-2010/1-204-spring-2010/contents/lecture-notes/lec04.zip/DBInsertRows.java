package src.db;
import java.sql.*;

// JDBC book, page 128
public class DBInsertRows {
	public static void main(String args[]) {
		String url = "jdbc:sqlserver://localhost\\SQLEXPRESS;databaseName=MIT1204;"+
		"user=gkocur3;password=car5940;";
		Connection con;
		Statement stmt;
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		} catch(ClassNotFoundException e) {
			System.err.print("ClassNotFoundException: ");
			System.err.println(e.getMessage());
		}
		try {
			con = DriverManager.getConnection(url);
			stmt = con.createStatement(
				ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet uprs = stmt.executeQuery("SELECT * FROM COFFEES");
			uprs.moveToInsertRow();
			uprs.updateString("COF_NAME", "Kona");
			uprs.updateInt("SUP_ID", 150);
			uprs.updateFloat("PRICE", 10.99f);
			uprs.updateInt("SALES", 0);
			uprs.updateInt("TOTAL", 0);
			uprs.insertRow();

			uprs.updateString("COF_NAME", "Kona_Decaf");
			uprs.updateInt("SUP_ID", 150);
			uprs.updateFloat("PRICE", 11.99f);
			uprs.updateInt("SALES", 0);
			uprs.updateInt("TOTAL", 0);
			uprs.insertRow();
			uprs.beforeFirst();

			System.out.println("Table COFFEES after insertion:");
			while (uprs.next()) {
				String name = uprs.getString("COF_NAME");
				int id = uprs.getInt("SUP_ID");
				float price = uprs.getFloat("PRICE");
				int sales = uprs.getInt("SALES");
				int total = uprs.getInt("TOTAL");
				System.out.print(name + "   " + id + "   " + price);
				System.out.println("   " + sales + "   " + total);
			}
			uprs.close();
			stmt.close();
			con.close();
		} catch(SQLException ex) {
			System.err.println("SQLException: " + ex.getMessage());
		}
	}
}