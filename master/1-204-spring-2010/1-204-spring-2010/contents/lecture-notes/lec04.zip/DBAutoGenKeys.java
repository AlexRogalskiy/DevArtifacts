package src.db;
import java.sql.*;

// JDBC book, p. 191
// Example does not work as written: Table COFFEE does not have a primary key, nor is it called KEY (line 14)
// Must create a PRIMARY KEY IDENTITY (in SQL Svr 2005) and it will work.

public class DBAutoGenKeys {
    public static void main(String args[]) {
    	String url = "jdbc:sqlserver://localhost\\SQLEXPRESS;databaseName=MIT1264F2007;"+
			"user=gkocur;password=car5940;";
		Connection con = null;
		PreparedStatement pstmt;
		String insert = "INSERT INTO COFFEES VALUES ('HYPER_BLEND', " +
											"101, 10.99, 0, 0)";
		String update = "UPDATE COFFEES SET PRICE = ? WHERE KEY = ?";
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		} catch(java.lang.ClassNotFoundException e) {
	        System.err.print("ClassNotFoundException: ");
		    System.err.println(e.getMessage());
		}
		try {
	    	con = DriverManager.getConnection(url);
			pstmt = con.prepareStatement(insert,
					Statement.RETURN_GENERATED_KEYS);
			pstmt.executeUpdate();
			ResultSet keys = pstmt.getGeneratedKeys();
			keys.next();
			int key = keys.getInt(1);

			pstmt = con.prepareStatement(update);
			pstmt.setFloat(1, 11.99f);
			pstmt.setInt(2, key);
			pstmt.executeUpdate();
			keys.close();
			pstmt.close();
	     	con.close();

		} catch (SQLException e) {
	    	e.printStackTrace();
		}
    }
}