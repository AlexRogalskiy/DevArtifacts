package src.backtrack;
import java.util.Arrays;

public class KnapsackBB {
	private DPItem[] items;	
	private int capacity;               // Max weight allowed in knapsack
	private int[] x;                    // Best solution array:item i in if xi=1
	private int[] y;                    // Working solution array at current tree node
	private double solutionProfit= -1;  // Profit of best solution so far
	private double currWgt;             // Weight of solution at this tree node
	private double currProfit;          // Profit of solution at this tree node
	private double newWgt;              // Weight of solution from bound() method
	private double newProfit;           // Profit of solution from bound() method
	private int k;                      // Level of tree in knapsack() method
	private int partItem;               // Level of tree in bound() method
	
	public KnapsackBB(DPItem[] i, int c) {
		items= i;
		capacity= c;
		x= new int[items.length];
		y= new int[items.length];
	}
	
	// knapsack() goes depth first through the tree to reach a leaf node, putting as many
	// full objects into the knapsack as possible. It then backtracks to the last full object
	// in the knapsack, and branches on it (takes it out of the solution) until it again either
	// reaches a leaf node (via a different path) or the upper bound is lower than the current
	// solution. In that case, there is no reason to proceed further down that path, and we 
	// backtrack again.  When we've backtracked to the root, we're done.

	public void knapsack() {
		int n= items.length;                      // Number of items in problem
		do {                                    // Truncate bound() to integer-do this later
			while (bound() <= solutionProfit) { // While upper bound < known solution, backtrack
				while (k != 0 && y[k] != 1)     // Back up while item k not in knapsack and not at root
					k--;                        // to find last object in knapsack
				if (k == 0)                     // If we've backtracked to root, we're done; return
					return;
				y[k]= 0;                        // Otherwise take item k out of solution (right branch in tree)
				currWgt -= items[k].weight;     // Reduce solution weight by item k's weight
				currProfit -= items[k].profit;  // Reduce solution profit by item k's profit
			}                                   // Go back to while statement and recompute bound()
			currWgt= newWgt;                    // Reach here if bound > solution profit, so we may have new soln
			currProfit= newProfit;              // Set current profit, weight to what bound() found
			k= partItem;                        // Set tree level k to that of the last (possibly partial) item in soln

			if (k == n) {                       // If we've reached a leaf node, we have actual solution, not just bound
				solutionProfit= currProfit;     // Update best solution profit, weight
				System.arraycopy(y, 0, x, 0, y.length);     // Copy solution into final solution array x
				k= n-1;                         // Back up to previous tree level or item, which we may take out of soln
			}
			else                                // Not at leaf node, so we just have a bound, not solution
				y[k]= 0;                        // Take last item k out of solution (backtrack)
		} while (true);                         // Infinite loop til we reach k=0 and return within it
	}

	// bound() method finds upper bound by moving left as much as possible
	// It then places a partial item into the solution to use up remaining capacity and computer upper bound
	// bound() computes a relaxation (it allows partial items in the knapsack, which may result in a profit estimate 
	// or upper bound that is higher than an actual integer solution would be

	private double bound() {
		boolean found= false;                   // Was bound found? I.e., is last item partial
		double boundVal= -1;                    // Value of upper bound
		int n= items.length;                      // Number of items in problem

		newProfit= currProfit;                  // Set new profit as current profit at this tree node
		newWgt= currWgt;
		partItem= k+1;                          // Go to next lower level (item) and try to put it in solution        
		// This is an item that is not in the knapsack now
		while (partItem < n && !found) {        // While more items remain and we haven't found a fractional item
			if (newWgt + items[partItem].weight <= capacity) {       // If item fits completely within capacity
				newWgt += items[partItem].weight;                    // Update new weight by adding item's weight
				newProfit += items[partItem].profit;              // Update new profit
				y[partItem]= 1;                             // Update current solution to show item k is in it
			}
			else {                              // Current item only fits partially
				boundVal= newProfit + (capacity - newWgt)*items[partItem].profit/items[partItem].weight;
				found= true;                    // Compute upper bound based on partial fit; set boolean
			}
			partItem++;                         // Go on to the next item and try to put it in the knapsack
		}
		if (found) {                            // If we have a fractional solution for last item in knapsack
			partItem--;                         // Back up to previous item, which is fully in the knapsack
			return boundVal;                    // Return the upper bound
		}
		else {                                  // Last item in current solution fit fully
			return newProfit; 			        // Return profit level including that last item
		}
	}

	private void outputSolution() {		// Almost identical to dynamic program knapsack output
		int totalProfit= 0;
		int totalWeight= 0;
		System.out.println("Items in solution:");
		// Position 0 in solution is sentinel; don't output
		for (int i= 1; i < x.length; i++)
			if (x[i] == 1) {
				System.out.println(items[i]);
				totalProfit += items[i].profit;
				totalWeight += items[i].weight;
			}
		System.out.println("\nProfit: " + totalProfit);
		System.out.println("Weight: " + totalWeight);
		
	}
	
	public static void main(String[] args) {
		// Sentinel- must be in 0 position even after sort
		DPItem[] list= {new DPItem(0, 0),
				new DPItem(11, 1),
				new DPItem(21, 11),
				new DPItem(31, 21),
				new DPItem(33, 23),
				new DPItem(43, 33),
				new DPItem(53, 43),
				new DPItem(55, 45),
				new DPItem(65, 55),
		};
		Arrays.sort(list, 1, list.length);	// Leave sentinel in position 0
		int capacity= 110;
		// Assume all item weights <= capacity. Not checked. Discard such items.
		// Assume all item profits > 0. Not checked.  Discard such items.
		KnapsackBB knap= new KnapsackBB(list, capacity);
		knap.knapsack();
		knap.outputSolution();
	}
}