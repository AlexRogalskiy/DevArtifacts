package src.dp;

public class DPItem implements Comparable<Object> {
	int profit;
	int weight;
	
	public DPItem(int p, int w) {
		profit= p;
		weight= w;
	}
	
	public String toString() {
		return ("Profit: " + profit + " weight: " + weight);
	}
	
	public boolean equals(Object other) {
		DPItem o= (DPItem) other;
		if (profit == o.profit && weight == o.weight)
			return true;
		else
			return false;
	}
	
	public int compareTo(Object o) {
		DPItem other = (DPItem) o;
		double ratio= (double) profit/weight;
		double otherRatio= (double) other.profit/other.weight;
		if (ratio > otherRatio)		// Descending sort
			return -1;
		else if (ratio < otherRatio)
			return 1;
		else
			return 0;
	}
}