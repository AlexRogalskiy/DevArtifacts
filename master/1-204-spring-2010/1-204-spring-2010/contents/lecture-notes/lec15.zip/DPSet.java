package src.dp;
import java.util.*;

public class DPSet {
	ArrayList<DPItem> data;	// Use ArrayList for flexible capacity, O(1) add 
	private static int capacity;
	
	public DPSet() {
		data= new ArrayList<DPItem>();
	}
	
	public static void setCapacity(int c) {
		capacity= c;
	}
	
	public DPSet extend(DPItem other) {	// Add item to set
		DPSet result= new DPSet();
		for (DPItem i: data) {
			int cumWgt= i.weight + other.weight;
			if (cumWgt <= capacity) {
				int cumProf= i.profit + other.profit;
				result.data.add(new DPItem(cumProf, cumWgt));
			}
		}
		return result;
	}

	public DPSet merge(DPSet other) {	// Items in any input sort order wind up in weight order
		DPSet result= new DPSet();
		int indexOther= 0;
		int maxIndexOther= other.data.size()-1;
		int lastItemProfitOther= other.data.get(maxIndexOther).profit; // Used for dominance check at end of set
		int index= 0;
		int maxIndex= data.size()-1;
		int lastItemProfit= data.get(maxIndex).profit;
		
		while (index <= maxIndex || indexOther <= maxIndexOther) {
			if (index <= maxIndex && indexOther <= maxIndexOther) {	// Both indexes in range
				DPItem item= data.get(index);
				DPItem otherItem= other.data.get(indexOther);
				if (item.weight < otherItem.weight) {
					result.data.add(item);	// Add item; can't be dominated by other item
					index++;
					while (otherItem.profit < item.profit && indexOther < maxIndexOther)	// Other item dominated; skip it
						otherItem= other.data.get(++indexOther);
				} else if (item.weight == otherItem.weight) { 
					if (item.profit >= otherItem.profit)	// Other item dominated
						indexOther++;
					else
						index++;							// Item dominated
				} else {	// otherItem.weight < item.weight
					result.data.add(otherItem);	//  Add other item, can't be dominated by item
					indexOther++;
					while (item.profit < otherItem.profit && index < maxIndex)	// item dominated; skip it
						item= data.get(++index);
				}
			}
			else if (index > maxIndex) {	// Only other items left to consider
				while (indexOther <= maxIndexOther) {
					DPItem otherItem= other.data.get(indexOther);
					if (otherItem.profit > lastItemProfit)
						result.data.add(otherItem);
					indexOther++;
				}
			} else {	// indexOther > maxIndexOther. Only items left to consider
				while (index <= maxIndex) {
					DPItem item= data.get(index);
					if (item.profit > lastItemProfitOther)
						result.data.add(item);
					index++;
				}
			}
		}
		return result;
	}
}