package src.dp;
import java.util.Arrays;

public class DPKnap {
	private DPItem[] items;
	private int m;				// Capacity of knapsack
	private DPSet[] sets;
	private DPItem[] solution;
	
	public DPKnap(DPItem[] i, int maxCap) {
		items= i;
		m= maxCap;
		sets= new DPSet[items.length];
		solution= new DPItem[items.length];
	}
	
	private void buildSets() {
		DPSet.setCapacity(m);
		// Build set 0 with node 0
		DPSet s= new DPSet();
		s.data.add(items[0]);		// Add item 0 to set 0. Sentinel w/0 profit, weight.
		sets[0]= s;
		
		// For sets 1 and above
		for (int i= 1; i < sets.length; i++) {
			DPSet sNext= s.extend(items[i]);		// Add item and find cumulative profit, weight
			s= s.merge(sNext);
			sets[i]= s;
		}
	}
	
	private void backPath() {
		int lastSetIndex= sets.length-1;	// Start at last set
		int lastSetItem= sets[lastSetIndex].data.size()-1;	// Get last item
		DPItem lastItem= sets[lastSetIndex].data.get(lastSetItem);
		
		int cumProfit= lastItem.profit;
		int cumWeight= lastItem.weight;
		DPItem prevItem= lastItem;
		
		for (int i= lastSetIndex-1; i >= 0; i--) {
			boolean itemFound= false;			// Is item in previous set
			int prevSetIndex= i+1;
			DPSet currSet= sets[i];
			int currItemIndex= currSet.data.size()-1;
			for (int j= currItemIndex; j >= 0; j--) {
				DPItem currItem= currSet.data.get(j);
				if (currItem.equals(prevItem)) {
					itemFound= true;
					break;
				}
				if (currItem.weight < prevItem.weight)	// No need to search further
					break;
			}
			// Pair (cum wgt, cum profit) not found in preceding set; item is in solution
			if (!itemFound) {
				solution[prevSetIndex]= items[prevSetIndex];
				cumProfit -= items[prevSetIndex].profit;
				cumWeight -= items[prevSetIndex].weight;
				prevItem= new DPItem(cumProfit, cumWeight);

			}	// else keep searching for prev item in the next set
		}
	}
	
	private void outputSolution() {
		int totalProfit= 0;
		int totalWeight= 0;
		System.out.println("Items in solution:");
		// Position 0 in solution is sentinel; don't output
		for (int i= 1; i < solution.length; i++)
			if (solution[i] != null) {
				System.out.println(items[i]);
				totalProfit += items[i].profit;
				totalWeight += items[i].weight;
			}
		System.out.println("\nProfit: " + totalProfit);
		System.out.println("Weight: " + totalWeight);
		
	}
	
	public void knapsack() {
		buildSets();
		backPath();
		outputSolution();
	}
	
	public static void main(String[] args) {
		// Sentinel- must be in 0 position even after sort
		DPItem[] list= {new DPItem(0, 0),
				new DPItem(11, 1),
				new DPItem(21, 11),
				new DPItem(31, 21),
				new DPItem(33, 23),
				new DPItem(43, 33),
				new DPItem(53, 43),
				new DPItem(55, 45),
				new DPItem(65, 55),
		};
		Arrays.sort(list, 1, list.length);	// Leave sentinel in position 0
		int capacity= 110;
		// Assume all item weights <= capacity. Not checked. Discard such items.
		// Assume all item profits > 0. Not checked.  Discard such items.
		DPKnap knap= new DPKnap(list, capacity);
		knap.knapsack();
	}
}